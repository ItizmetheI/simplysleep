# Simply Rest MattressNut-Style Build Handoff

Date: 2026-06-18


## Strategic Brief

See `00_STRATEGIC_GOAL_AND_PUBLISH_GATES.md` first. This package is a controlled implementation kit, not blind-publish copy. Final URL decisions, current product facts, reviewer approvals, schema validation, sitemap inclusion, and MattressNut comparator checks are required before launch.

## Added Control Layer

- `qa/PACKAGE_AUDIT_FINDINGS.md`
- `qa/content_cleanup_queue.csv`
- `qa/schema_publish_safety_queue.csv`
- `qa/url_equity_external_spotcheck.csv`
- `implementation/09_LAUNCH_CONTROL_PLAYBOOK.md`
- `implementation/10_URL_REFRESH_DECISION_NOTES.md`
- `trackers/simplyrest_go_live_gate_tracker.csv`

## What This Is

This package turns Simply Rest into a MattressNut-style AEO/LLM citation property with stronger proof controls.

It follows this WordPress implementation package shape:

- `package/pages/<slug>/<slug>.md`
- `package/pages/<slug>/<slug>.json`
- `package/reviews/<slug>/<slug>.md`
- `package/reviews/<slug>/<slug>.json`
- `package/comparisons/<slug>/<slug>.md`
- `package/comparisons/<slug>/<slug>.json`
- `package/foundation/<slug>/<slug>.md`
- `package/foundation/<slug>/<slug>.json`
- `package/site/llms.txt`
- `package/site/robots-additions.txt`
- `qa/url-qa/*`
- `qa/evidence-registers/*`
- `trackers/simplyrest_batch_001_url_tracker.csv`
- `batch_manifest.json`

## Deploy Order

1. Read `implementation/00_HUMAN_START_HERE.md`.
2. Complete `implementation/01_URL_DECISION_MATRIX.md`.
3. Publish foundation pages: methodology, expert reviewers, editorial policy, disclosure.
4. Treat `package/site/llms.txt` as a draft plan until final URLs are chosen; then add `/llms.txt`.
5. Add robots.txt AI crawler review additions if approved.
6. Refresh existing high-fit URLs where a URL already exists.
7. Publish `/reviews/` and product review pages.
8. Publish approved `/comparison/` pages with top recommendation boxes.
9. Publish new Batch 001 URLs.
10. Validate schema and sitemap inclusion.
11. Start weekly AI citation capture.

## Hard Gate

Do not publish as final until WordPress facts, prices, product claims, reviewer approval, and schema validity are checked.

## All Content Refresh Update

Active page files have been moved to current canonical build slugs where overlap was confirmed. Use `implementation/12_ACTIVE_PAGE_BUILD_MAP.csv` as the source of truth. Do not publish legacy `*-2026` duplicate URLs unless they appear as the approved canonical target in that map.
