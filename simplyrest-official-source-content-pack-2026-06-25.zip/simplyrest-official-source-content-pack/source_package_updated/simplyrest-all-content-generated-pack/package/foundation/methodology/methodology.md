---
title: "How Simply Rest Reviews and Recommends Mattresses"
canonical_url: "https://simplyrest.com/methodology/"
site: "Simply Rest"
status: "Official-source researched WordPress draft - live price, affiliate links, schema validation, and final WordPress QA QA still required"
last_updated: "2026-06-25"
fact_source_basis: "Official brand/product/support pages reviewed 2026-06-25"
schema_file: "methodology.json"
---
# How Simply Rest Reviews and Recommends Mattresses

Simply Rest recommendations should be built around source-backed product facts, shopper-fit logic, and conservative proof standards.

## Inputs we use

- Official product pages and brand support pages.
- Trial, return, warranty, shipping, and certification pages.
- Current product names and active configurations.
- Fit logic by sleep position, firmness preference, body type, heat sensitivity, material preference, partner needs, and budget.

## Inputs we do not invent

- Hands-on lab scores.
- Medical outcomes.
- Current prices or promotions without a dated source.
- Product specs not shown by a current source.
- Reviewer approval not documented internally.

## Ranking method

A mattress should rank higher when its current source-backed facts match the page intent more clearly than the alternatives. A mattress should rank lower when the claim would require unsourced testing, medical language, stale pricing, or unverified certification scope.

