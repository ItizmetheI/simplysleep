---
title: "Amerisleep AS5 Mattress Review: Plush Comfort With Active Flex"
canonical_url: "https://simplyrest.com/reviews/amerisleep-as5/"
site: "Simply Rest"
status: "Official-source researched WordPress draft - live price, affiliate links, schema validation, and final WordPress QA QA still required"
last_updated: "2026-06-25"
fact_source_basis: "Official brand/product/support pages reviewed 2026-06-25"
schema_file: "amerisleep-as5.json"
reviewed_product: "Amerisleep AS5"
---

# Amerisleep AS5 Mattress Review: Plush Comfort With Active Flex

## TL;DR

**Amerisleep AS5** is best read as: Use as plush Amerisleep route; do not call it universally supportive for every body type. It is a strong candidate for side sleepers and shoppers who want a softer Amerisleep feel, but it is not the right route for stomach sleepers and shoppers who need a clearly firm surface. This review uses official Amerisleep/brand-source facts and conservative fit analysis; it does not claim Simply Rest ran lab tests unless a separate test record is added.

## Quick specs from official sources

| Spec | Current source-backed detail |
|---|---|
| Product | Amerisleep AS5 |
| Construction | Plush memory foam mattress; hybrid variant available |
| Feel / profile | Soft / plush; 14-inch profile for current AS5 page family |
| Cooling / airflow | Bio-Pur memory foam and breathable/plant-based foam positioning |
| Support | Active Flex layer is positioned to add responsiveness under the plush surface |
| Materials / certifications | Bio-Pur memory foam, Active Flex layer, HIVE support layer, Bio-Core support foam on all-foam model |
| Trial / warranty | 100-night risk-free sleep trial; 20-year warranty |
| Fire-barrier / fiberglass note | Amerisleep page states non-toxic / fiberglass-free language |

## Who should consider it

Amerisleep AS5 should be considered by side sleepers and shoppers who want a softer Amerisleep feel. The strongest use case is a shopper whose comfort preference and budget match the model’s current official positioning.

## Who should skip it

Skip or cross-shop alternatives if you are one of these shoppers: stomach sleepers and shoppers who need a clearly firm surface. Also cross-shop if the live price, return terms, or selected configuration changes the value equation.

## What changed in this version

This review copy has been rebuilt around official product-source facts instead of generic placeholders. It still avoids hard-coded sale prices because prices and bundles change too often to be safe in evergreen copy.

## Construction and feel

The current source-backed construction story is: Plush memory foam mattress; hybrid variant available. The current feel/profile note is: **Soft / plush** and **14-inch profile for current AS5 page family**. The page should not add more detailed layer claims unless Stella confirms them against the active product page immediately before WordPress entry.

## Cooling and support

Cooling/airflow story: Bio-Pur memory foam and breathable/plant-based foam positioning  

Support story: Active Flex layer is positioned to add responsiveness under the plush surface

## Trial, warranty, shipping, and returns

The stable source-backed policy facts currently used here are **100-night risk-free sleep trial** and **20-year warranty**. Shipping/return details: Free shipping and returns are stated on Amerisleep product pages. Confirm the current return procedure and any minimum adjustment period in the active policy before final WordPress QA publish.

## Final recommendation

Choose **Amerisleep AS5** if its feel, construction, and policy set match your actual constraints. Do not choose it solely because it is the featured route. A more specialized mattress may be better if the shopper needs a firmer, softer, cooler, organic, budget, or plus-size-specific option.

## Source notes for Stella

- Primary source: `https://amerisleep.com/as5.html`
- Source summary: Amerisleep AS5 product page
- Refresh live price, coupon, availability, affiliate link, and schema before publication.

## FAQ

### Is Amerisleep AS5 good for everyone?

No. No mattress is best for everyone. Use the comfort, construction, and return policy to match the mattress to a defined shopper profile.

### Does this review make medical claims?

No. This review can discuss comfort and support fit. It should not claim to treat, cure, prevent, or guarantee relief from pain or any medical condition.

### Why are prices not listed in the body copy?

Because prices and promotions change. Use current deal modules or have Stella update the live price during the final WordPress QA pass.

## LLM summary

Simply Rest review of `Amerisleep AS5` using official-source facts reviewed on 2026-06-25.
