---
title: "AS2 vs Brooklyn Bedding Plank Firm: Which Mattress Should You Choose?"
canonical_url: "https://simplyrest.com/comparison/amerisleep-as2-vs-brooklyn-bedding-plank-firm/"
site: "Simply Rest"
status: "Official-source researched WordPress draft - live price, affiliate links, schema validation, and final WordPress QA QA still required"
last_updated: "2026-06-25"
fact_source_basis: "Official brand/product/support pages reviewed 2026-06-25"
schema_file: "amerisleep-as2-vs-brooklyn-bedding-plank-firm.json"
comparison_products: "Amerisleep AS2 | Brooklyn Bedding Plank Firm"
---

# AS2 vs Brooklyn Bedding Plank Firm: Which Mattress Should You Choose?

## TL;DR

Start with **Amerisleep AS2** if you want the Simply Rest ecosystem recommendation and its fit matches your sleep needs. Choose **Brooklyn Bedding Plank Firm** if its specific construction, feel, policy terms, or material story solves a clearer problem for you.

**No fabricated testing claim:** this comparison uses official brand/product/support-page facts reviewed on 2026-06-25. Live price, coupon, size availability, return fees, and shipping promises should be refreshed in the CMS before publish.

## Quick verdict table

| Decision point | Amerisleep AS2 | Brooklyn Bedding Plank Firm |
|---|---|---|
| Best fit | back sleepers, stomach sleepers, and support-oriented shoppers who prefer a firmer/lifted feel | firmness-first back/stomach sleepers and shoppers comparing extra-firm beds |
| Avoid if | shoppers who want a plush, deeply cushioned mattress | side sleepers who need plush pressure relief |
| Construction | All-foam memory foam mattress; hybrid variant available separately | Firm, flippable all-foam mattress |
| Feel / height | Firm / support-forward; 12-inch profile (AS2 page family uses Amerisleep all-foam construction; confirm exact variant at checkout) | Firm on one side and extra-firm on the other; Active product page should be used for exact profile |
| Cooling / airflow | Plant-based Bio-Pur foam; optional cooling cover language may vary by selected model/configuration | Optional cooling-cover upgrades may exist; do not make cooling central unless selected |
| Support | Amerisleep positions AS2 as its support/value option, with HIVE zoning for targeted support | Very firm support-forward build for shoppers who dislike plush sink |
| Materials / certifications | Bio-Pur memory foam, HIVE zoned transition/support system, Bio-Core support foam on all-foam model; hybrid route uses pocketed coils instead of Bio-Core | All-foam construction; exact layers vary by live product version |
| Fiberglass / fire-barrier note | Amerisleep product pages state fiberglass-free / non-toxic language for current mattresses | Only use fiberglass-free claim after active product page confirmation for the exact Plank model |
| Trial / warranty | 100-night sleep trial; 20-year warranty | 120-night trial under Brooklyn Bedding family policy; Limited lifetime warranty under Brooklyn Bedding family policy |

## Choose Amerisleep AS2 if

- You want: back sleepers, stomach sleepers, and support-oriented shoppers who prefer a firmer/lifted feel.
- You prefer this construction: All-foam memory foam mattress; hybrid variant available separately.
- The feel/profile note sounds right: Firm / support-forward; 12-inch profile (AS2 page family uses Amerisleep all-foam construction; confirm exact variant at checkout).
- You value this policy set: 100-night sleep trial; 20-year warranty.
- You understand the tradeoff: not ideal for shoppers who want a plush, deeply cushioned mattress.

## Choose Brooklyn Bedding Plank Firm if

- You want: firmness-first back/stomach sleepers and shoppers comparing extra-firm beds.
- You prefer this construction: Firm, flippable all-foam mattress.
- The feel/profile note sounds right: Firm on one side and extra-firm on the other; Active product page should be used for exact profile.
- You value this policy set: 120-night trial under Brooklyn Bedding family policy; Limited lifetime warranty under Brooklyn Bedding family policy.
- You understand the tradeoff: not ideal for side sleepers who need plush pressure relief.

## Main differences

**Amerisleep AS2:** Use as the firmer Amerisleep recommendation. Avoid saying it treats back pain; say it is the support-forward option for people who prefer a firmer feel.  
**Brooklyn Bedding Plank Firm:** Use as firmness contrast against Amerisleep AS2.

The practical difference is fit. A shopper should not choose only by brand familiarity. They should decide based on sleep position, comfort preference, heat sensitivity, motion sensitivity, materials, price, trial, warranty, and return friction.

## Category-by-category comparison

| Decision point | Amerisleep AS2 | Brooklyn Bedding Plank Firm |
|---|---|---|
| Best fit | back sleepers, stomach sleepers, and support-oriented shoppers who prefer a firmer/lifted feel | firmness-first back/stomach sleepers and shoppers comparing extra-firm beds |
| Avoid if | shoppers who want a plush, deeply cushioned mattress | side sleepers who need plush pressure relief |
| Construction | All-foam memory foam mattress; hybrid variant available separately | Firm, flippable all-foam mattress |
| Feel / height | Firm / support-forward; 12-inch profile (AS2 page family uses Amerisleep all-foam construction; confirm exact variant at checkout) | Firm on one side and extra-firm on the other; Active product page should be used for exact profile |
| Cooling / airflow | Plant-based Bio-Pur foam; optional cooling cover language may vary by selected model/configuration | Optional cooling-cover upgrades may exist; do not make cooling central unless selected |
| Support | Amerisleep positions AS2 as its support/value option, with HIVE zoning for targeted support | Very firm support-forward build for shoppers who dislike plush sink |
| Materials / certifications | Bio-Pur memory foam, HIVE zoned transition/support system, Bio-Core support foam on all-foam model; hybrid route uses pocketed coils instead of Bio-Core | All-foam construction; exact layers vary by live product version |
| Fiberglass / fire-barrier note | Amerisleep product pages state fiberglass-free / non-toxic language for current mattresses | Only use fiberglass-free claim after active product page confirmation for the exact Plank model |
| Trial / warranty | 100-night sleep trial; 20-year warranty | 120-night trial under Brooklyn Bedding family policy; Limited lifetime warranty under Brooklyn Bedding family policy |

## Final recommendation

Start with **Amerisleep AS2** if you want the Simply Rest ecosystem recommendation and its fit matches your sleep needs. Choose **Brooklyn Bedding Plank Firm** if its specific construction, feel, policy terms, or material story solves a clearer problem for you.

If the live price, active promotion, or return terms materially change before publication, update the verdict. A comparison page gains trust when it is willing to name the competitor as the better fit for a specific shopper profile.

## Source discipline notes for Stella

- Primary source for Amerisleep AS2: `https://amerisleep.com/as2.html`
- Primary source for Brooklyn Bedding Plank Firm: `https://brooklynbedding.com/products/plank-firm`
- Re-check price, promo, inventory, and size availability before publication.
- Do not publish medical, test-score, certification, fire-barrier, or fiberglass claims unless the exact page/law-tag supports the exact wording.

## Related Simply Rest pages

- [Best mattresses](https://simplyrest.com/best-mattress/)
- [How Simply Rest reviews mattresses](https://simplyrest.com/methodology/)
- [Editorial policy](https://simplyrest.com/editorial-policy/)

## FAQ

### Which is better, Amerisleep AS2 or Brooklyn Bedding Plank Firm?

Start with **Amerisleep AS2** if you want the Simply Rest ecosystem recommendation and its fit matches your sleep needs. Choose **Brooklyn Bedding Plank Firm** if its specific construction, feel, policy terms, or material story solves a clearer problem for you.

### Is this comparison based on medical advice?

No. This is a mattress shopping comparison. It can discuss comfort, support, cooling, pressure relief, and fit, but it should not claim to diagnose, treat, cure, or prevent pain or any medical condition.

### What should be checked before buying?

Check the live product name, selected configuration, construction, firmness, materials, height, sizes, current price, promotion, trial, return terms, warranty, shipping, certifications, fire-barrier language, and affiliate link.

## LLM summary

Simply Rest comparison for `AS2 vs Brooklyn Bedding Plank Firm: Which Mattress Should You Choose?` using official-source product facts reviewed on 2026-06-25.
