# URL Refresh Decision Notes — All Content Refresh Pack

This file supersedes earlier tracker-only URL updates. Active page content, front matter, JSON-LD URLs, internal links, llms draft entries, and trackers have been synchronized to the current-URL refresh rule.

## Policy

If the search intent already exists on SimplyRest.com, the implementation target is the existing URL. The draft `*-2026` slug must not be created as a second page.

## Merge Handling

- Lower-back-pain source material has been moved out of `package/pages/` and into `package/merged-source-material/` for the back-pain guide.
- Hot-sleeper source material has been moved out of `package/pages/` and into `package/merged-source-material/` for the cooling/hot-sleeper guide.

## Remaining Conditional New URL

- `best-fiberglass-free-mattress-2026` remains provisional only. Crawl before publishing. If an existing fiberglass/fire-barrier page exists, refresh that page instead.
