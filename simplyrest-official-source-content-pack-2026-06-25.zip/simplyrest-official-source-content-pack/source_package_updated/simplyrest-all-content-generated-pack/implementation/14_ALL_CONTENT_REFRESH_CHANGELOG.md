# All Content Refresh Changelog

## Completed in this package

- Renamed active best-of page folders and files from provisional package slugs to active canonical build slugs where overlap was confirmed.
- Moved duplicate lower-back-pain and hot-sleeper drafts out of active `package/pages/` into `package/merged-source-material/`.
- Updated active Markdown front matter with `url_action`, `legacy_package_slug`, `active_build_slug`, `publish_url`, and `do_not_publish_url` controls.
- Updated active page body copy with URL refresh status blocks.
- Updated active JSON-LD `url`, `@id`, breadcrumb, `mainEntityOfPage`, Article, WebPage, and ItemList URL references to current canonical URLs.
- Rebuilt Batch 001 tracker and go-live gate tracker around canonical refresh targets.
- Rebuilt `package/site/llms.txt` so active priority pages point to existing canonical URLs and merged pages are not listed as standalone pages.
- Added direct implementation maps for active pages and do-not-publish duplicate URLs.

## Still intentionally blocked

- Live WordPress content has not been edited because this environment has no WordPress/CMS deployment access.
- Current product prices, availability, warranty, trial, material claims, certification claims, and reviewer approvals still require source-of-truth verification before publish.
- Schema still requires validation after final WordPress fields, authors, breadcrumbs, and publish dates are locked.
