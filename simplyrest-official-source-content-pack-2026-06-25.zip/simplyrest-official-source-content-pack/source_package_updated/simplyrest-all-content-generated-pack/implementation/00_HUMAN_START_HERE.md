# Start Here — All Content Refresh Pack

1. Open `implementation/12_ACTIVE_PAGE_BUILD_MAP.csv`.
2. Build only rows marked as standalone pages.
3. For overlap rows, update the existing WordPress URL in place.
4. Do not publish legacy `*-2026` URLs listed in `implementation/13_DO_NOT_PUBLISH_DUPLICATE_2026_URLS.md`.
5. Treat merged source material as copy modules only, not standalone pages.

---

# Human Implementation Start Here

Date: 2026-06-18

This package is meant for a human WordPress implementer. It is not a blind publish package. Every page is a structured draft that needs final WordPress facts, URL decisions, and QA before publish.

## First Action

Read `../00_STRATEGIC_GOAL_AND_PUBLISH_GATES.md`, then resolve URL decisions before building page copy. Do not upload `llms.txt` or JSON-LD until final URLs are locked.

## Folder Map

| Folder/file | What to do |
|---|---|
| `package/foundation/*/*.md` | Create or update foundation pages first. |
| `package/foundation/*/*.json` | Add page-level JSON-LD only after schema validation. |
| `package/pages/*/*.md` | Use as article build briefs and copy source. Expand into full posts before publish. |
| `package/pages/*/*.json` | Draft JSON-LD for the matching page. Validate before adding. |
| `package/reviews/*/*.md` | Product review index and product review page drafts. |
| `package/reviews/*/*.json` | Draft JSON-LD for review pages. Validate before adding. |
| `package/comparisons/*/*.md` | Comparison page drafts with top recommendation boxes. |
| `package/comparisons/*/*.json` | Draft JSON-LD for comparison pages. Validate before adding. |
| `package/site/llms.txt` | Upload to root `/llms.txt` after final URLs are chosen. |
| `package/site/robots-additions.txt` | Proposed robots additions. Review before changing live robots. |
| `implementation/01_URL_DECISION_MATRIX.md` | Decide whether each page updates an existing URL or creates a new URL. |
| `implementation/02_WORDPRESS_FIELD_MAP.md` | Copy/paste map for WordPress and Rank Math fields. |
| `implementation/03_PAGE_BUILD_ORDER.md` | Recommended implementation order. |
| `implementation/04_FINAL_QA_CHECKLIST.md` | Final human QA checklist before publish. |
| `trackers/simplyrest_batch_001_url_tracker.csv` | Working tracker for status, comparator, and publish gate. |

## Non-Negotiables

- Do not publish bracket labels like `[EXECUTIVE_SUMMARY]`; convert them into normal headings or blocks.
- Do not publish "Verify current price..." rows; replace with final product facts.
- Do not publish reviewer names or `reviewedBy` schema unless approval is documented.
- Do not claim Simply Rest tested a mattress unless a test record exists.
- Do not create a new 2026 URL when an existing URL should be refreshed.
- Do not publish comparison pages without a top recommendation box.
- Do not create skipped comparison routes.

## Human Workflow

1. Choose the URL path.
2. Build the WordPress article from the `.md` file.
3. Replace all draft/verification language with final facts.
4. Add internal links.
5. Add FAQ block visibly on page.
6. Add JSON-LD after validation.
7. Confirm sitemap inclusion.
8. Update `/llms.txt`.
9. Mark tracker complete.
