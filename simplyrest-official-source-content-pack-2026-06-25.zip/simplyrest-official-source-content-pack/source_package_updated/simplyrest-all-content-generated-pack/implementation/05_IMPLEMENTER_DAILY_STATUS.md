# Implementer Daily Status Template

Use this as a quick status note after each implementation session.

## Completed Today

- URL:
- Work done:
- Schema added:
- Internal links added:
- QA status:

## Blocked / Needs Joel

- Product fact:
- Reviewer approval:
- URL decision:
- Claim approval:

## Next Session

- Next URL:
- Next QA item:
