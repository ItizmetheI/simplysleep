# Do Not Publish Duplicate 2026 URLs

These URLs are preserved only as audit references. Do not create them in WordPress unless a later URL governance decision explicitly reverses the current refresh rule.

| Legacy draft URL | Correct action | Target URL |
|---|---|---|
| `https://simplyrest.com/best-mattress-2026/` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattress/` |
| `https://simplyrest.com/best-mattress-for-back-pain-2026/` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattress-for-back-pain/` |
| `https://simplyrest.com/best-mattress-for-lower-back-pain-2026/` | MERGE_INTO_EXISTING_URL | `https://simplyrest.com/best-mattress-for-back-pain/` |
| `https://simplyrest.com/best-mattress-for-side-sleepers-2026/` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattress-side-sleepers/` |
| `https://simplyrest.com/best-mattress-for-heavy-people-2026/` | REFRESH_EXISTING_URL | `https://simplyrest.com/whats-the-best-mattress-for-plus-size-people/` |
| `https://simplyrest.com/best-cooling-mattress-2026/` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-cooling-mattress-for-hot-sleepers/` |
| `https://simplyrest.com/best-mattress-for-hot-sleepers-2026/` | MERGE_INTO_EXISTING_URL | `https://simplyrest.com/best-cooling-mattress-for-hot-sleepers/` |
| `https://simplyrest.com/best-organic-mattress-2026/` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-organic-mattress/` |
| `https://simplyrest.com/best-mattress-under-1000-2026/` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattresses-for-under-1000/` |
| `https://simplyrest.com/best-mattress-for-couples-2026/` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattress-for-couples/` |
| `https://simplyrest.com/best-mattress-for-the-money-2026/` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattress-for-the-money/` |
