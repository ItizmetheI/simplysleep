# WordPress Field Map

Use this map for every page.

| Source | WordPress / Rank Math field |
|---|---|
| Markdown `title` | Post title / SEO title base |
| Markdown `canonical_url` | Permalink and canonical URL |
| Markdown `target_query` | Focus keyword |
| Markdown H1 | Page H1 |
| `[EXECUTIVE_SUMMARY]` | Intro block under H1 |
| `[QUICK_ANSWER]` | Answer-first block / highlighted paragraph |
| `[BUYER_DECISION_MATRIX]` | HTML table block |
| `[WHY_WE_PICKED_THE_WINNER]` | Product winner explanation section |
| `[BEST_FOR]` | Bullet section |
| `[NOT_FOR]` | Bullet section |
| `[EXPERT_REVIEW_MODULE]` | Expert/reviewer box only after approval |
| `[PROOF_AND_CLAIM_SCOPE]` | Internal guidance; convert into visible methodology language where useful |
| `[MATTRESSNUT_COMPARATOR]` | Internal QA only; do not publish |
| `[INTERNAL_LINKS]` | Add as contextual links, not a raw list if possible |
| `[FAQ]` | Visible FAQ block |
| JSON file | Add as page-level JSON-LD after validation |

## Copy Cleanup Rules

- Remove all bracket tokens before publishing.
- Remove all "before publish" and "verify" language from visible copy.
- Replace generic labels like "premium alternative" with product-specific reasoning.
- Rewrite FAQ questions so they sound human.
- Add affiliate disclosure near the top or before first CTA.
