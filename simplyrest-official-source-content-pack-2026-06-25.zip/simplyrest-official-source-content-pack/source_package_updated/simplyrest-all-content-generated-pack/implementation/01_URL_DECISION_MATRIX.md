# URL Decision Matrix — All Content Refresh Pack

Controlling rule: when a draft overlaps a current Simply Rest URL, update the current URL in WordPress and do not publish a duplicate `*-2026` URL.

| Priority | Legacy package slug | Active build slug | Action | Canonical URL | Standalone page? | Instruction |
|---|---|---|---|---|---:|---|
| P01 | `best-mattress-2026` | `best-mattress` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattress/` | Yes | Refresh the current Best Mattress hub. Do not create /best-mattress-2026/. |
| P02 | `best-mattress-for-back-pain-2026` | `best-mattress-for-back-pain` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattress-for-back-pain/` | Yes | Refresh the current back-pain guide. Merge lower-back-pain source material here unless later keyword review proves a separate page. |
| P03 | `best-mattress-for-lower-back-pain-2026` | `best-mattress-for-back-pain` | MERGE_INTO_EXISTING_URL | `https://simplyrest.com/best-mattress-for-back-pain/` | No | Merge into /best-mattress-for-back-pain/. No standalone page by default. |
| P04 | `best-mattress-for-side-sleepers-2026` | `best-mattress-side-sleepers` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattress-side-sleepers/` | Yes | Refresh the current side-sleeper guide. Do not create /best-mattress-for-side-sleepers-2026/. |
| P05 | `best-mattress-for-heavy-people-2026` | `whats-the-best-mattress-for-plus-size-people` | REFRESH_EXISTING_URL | `https://simplyrest.com/whats-the-best-mattress-for-plus-size-people/` | Yes | Refresh the current plus-size/heavy-sleeper URL. Keep existing URL unless Search Console/backlink review justifies a slug change. |
| P06 | `best-cooling-mattress-2026` | `best-cooling-mattress-for-hot-sleepers` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-cooling-mattress-for-hot-sleepers/` | Yes | Refresh the current cooling/hot-sleeper guide. Merge hot-sleeper source material here. |
| P07 | `best-mattress-for-hot-sleepers-2026` | `best-cooling-mattress-for-hot-sleepers` | MERGE_INTO_EXISTING_URL | `https://simplyrest.com/best-cooling-mattress-for-hot-sleepers/` | No | Merge into /best-cooling-mattress-for-hot-sleepers/. No standalone page by default. |
| P08 | `best-fiberglass-free-mattress-2026` | `best-fiberglass-free-mattress-2026` | NEW_URL_IF_NO_CURRENT_OVERLAP | `https://simplyrest.com/best-fiberglass-free-mattress-2026/` | Yes | New URL remains provisional. Crawl SimplyRest.com first; if any fiberglass/fire-barrier URL exists, refresh that instead. |
| P09 | `best-organic-mattress-2026` | `best-organic-mattress` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-organic-mattress/` | Yes | Refresh the current organic mattress guide. Do not create /best-organic-mattress-2026/. |
| P10 | `best-mattress-under-1000-2026` | `best-mattresses-for-under-1000` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattresses-for-under-1000/` | Yes | Refresh the current under-$1,000 URL. Do not create /best-mattress-under-1000-2026/. |
| P11 | `best-mattress-for-couples-2026` | `best-mattress-for-couples` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattress-for-couples/` | Yes | Refresh the current couples guide. Do not create /best-mattress-for-couples-2026/. |
| P12 | `best-mattress-for-the-money-2026` | `best-mattress-for-the-money` | REFRESH_EXISTING_URL | `https://simplyrest.com/best-mattress-for-the-money/` | Yes | Refresh the current value/money URL. Do not create /best-mattress-for-the-money-2026/. |

## Hard Block

Do not publish any legacy `*-2026` URL when the same intent already has a Simply Rest URL. Legacy URLs remain only as package IDs, source-material IDs, or do-not-publish audit references.
