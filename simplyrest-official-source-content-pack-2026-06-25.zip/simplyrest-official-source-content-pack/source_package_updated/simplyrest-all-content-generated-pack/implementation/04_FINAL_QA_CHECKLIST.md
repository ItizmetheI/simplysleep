# Final QA Checklist

Use this before pressing Publish or Update.

## Content QA

- [ ] Bracket section tokens removed.
- [ ] Draft/verify language removed from visible copy.
- [ ] FAQ questions rewritten naturally.
- [ ] Product order approved.
- [ ] Product facts verified.
- [ ] Affiliate disclosure visible.
- [ ] Internal links added.
- [ ] No duplicated live URL conflict.

## Claim QA

- [ ] No hands-on testing claim unless test record exists.
- [ ] No treatment/cure/prevention/diagnosis claim.
- [ ] Pain pages use comfort/support/alignment language.
- [ ] Certification claims are component-specific unless whole-product proof exists.
- [ ] Cooling claims avoid guarantees like "keeps cool all night."

## Schema QA

- [ ] JSON-LD validates.
- [ ] FAQPage schema only used if FAQ is visible.
- [ ] `reviewedBy` only added after reviewer approval.
- [ ] MedicalWebPage only added after medical/reviewer approval.
- [ ] Canonical URL in schema matches WordPress canonical.

## AEO / AI QA

- [ ] Page appears in sitemap.
- [ ] Page included in `/llms.txt`.
- [ ] Answer-first intro is visible under H1.
- [ ] Comparison table is visible in HTML.
- [ ] MattressNut comparator row completed in tracker.
