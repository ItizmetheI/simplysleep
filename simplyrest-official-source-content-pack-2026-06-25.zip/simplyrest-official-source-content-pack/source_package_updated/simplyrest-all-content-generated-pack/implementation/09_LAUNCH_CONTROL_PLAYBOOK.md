# Simply Rest Launch Control Playbook

Date: 2026-06-22

## Operating Principle

Move fast, but do not let speed create crawlable liabilities. The package should be implemented as controlled batches with explicit go/no-go gates.

## Phase 0 — URL and Canonical Lock

**Owner lane:** SEO lead + Joel approval

1. Export current WordPress URL list, sitemap URLs, Search Console landing pages, and backlink/traffic data.
2. For every package slug, choose one of three actions:
   - Refresh existing URL.
   - Create new URL.
   - Consolidate and 301 redirect.
3. Update the chosen canonical everywhere:
   - Markdown front matter.
   - JSON-LD `url`, `@id`, breadcrumb items, and `mainEntityOfPage`.
   - Trackers.
   - `llms.txt`.
   - Internal links.
4. Do not build duplicate `*-2026` URLs unless the existing URL is intentionally deprecated.

## Phase 1 — Foundation Pages

**Owner lane:** Content + WP implementer

Build or refresh:

- `/methodology/`
- `/editorial-policy/`
- `/disclosure/`
- `/expert-reviewers/`

Gate:

- Visible affiliate disclosure.
- Methodology clearly says Simply Rest does not claim hands-on testing without records.
- Reviewer page does not imply endorsement beyond documented approval.

## Phase 2 — Product Evidence Register

**Owner lane:** Content QA

For every product appearing in a recommendation table, review page, or comparison page, record:

- Current product name.
- Live product URL.
- Current price or price range.
- Trial.
- Warranty.
- Firmness/feel.
- Height/construction.
- Materials.
- Fire barrier/fiberglass statement.
- Certifications and whether they are product-level or component-level.
- Availability/discontinuation status.
- Date checked.
- Source URL.

Gate:

- No page can publish with an unchecked product in its table.

## Phase 3 — Pilot Page Build

**Recommended pilot:** a high-intent existing URL such as `/best-mattress-for-the-money/`, `/best-mattress-for-back-pain/`, or `/best-mattress-for-couples/`.

Build requirements:

- Answer-first intro under H1.
- Visible disclosure before first commercial CTA.
- Final product table with current facts.
- Clear winner logic.
- “Best for” and “not for” sections.
- Relevant review/comparison links.
- Visible FAQ block.
- Schema matched to visible content.
- No draft labels, verify rows, or internal QA notes.

## Phase 4 — Schema and LLM Gate

**Owner lane:** Technical SEO + WP implementer

1. Validate JSON-LD in Schema.org validator and Google Rich Results Test.
2. Confirm schema URLs match final canonical URLs.
3. Confirm `FAQPage` schema only exists when FAQ copy is visible.
4. Do not use `reviewedBy` or `MedicalWebPage` without documented reviewer/medical approval.
5. Update `llms.txt` only after URLs are final and pages are live/indexable.

## Phase 5 — MattressNut Comparator Gate

For each page, record:

- Closest MattressNut URL.
- MattressNut H1/title.
- Approximate word count.
- Schema types.
- Top-page modules.
- Claim risks to avoid copying.
- Simply Rest differentiation.

Gate:

- Simply Rest must not imitate unsupported testing or medical claims. Its edge should be tighter proof discipline, cleaner answer-first structure, and conservative shopper-fit recommendations.

## Phase 6 — Batch Launch

Recommended cadence:

1. Foundation pages.
2. 1 pilot best-of page.
3. Reviews hub + 2 product reviews.
4. 3-5 comparison pages.
5. Remaining best-of pages.
6. Remaining reviews and comparisons.

## Definition of Done

A launched page is done when:

- Final URL is live with 200 status or intentional redirect.
- Canonical is correct.
- Title/H1/meta are final.
- Draft language is gone.
- Product facts are checked.
- Claims are clean.
- Schema validates.
- Sitemap includes the page.
- `llms.txt` includes the final URL.
- Tracker status is updated.

## Daily Implementer Update Format

Use `implementation/05_IMPLEMENTER_DAILY_STATUS.md` and include:

- URLs completed.
- URLs blocked.
- Proof/fact gaps.
- Reviewer approval gaps.
- Schema validation status.
- Next batch.
