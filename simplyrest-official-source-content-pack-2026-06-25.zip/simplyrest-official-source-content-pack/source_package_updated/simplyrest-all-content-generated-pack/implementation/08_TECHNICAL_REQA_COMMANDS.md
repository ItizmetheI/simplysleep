# Technical Re-QA Commands

Run against the final production host after implementation.

```bash
BASE="https://simplyrest.com"

curl -I "$BASE/"
curl -I "$BASE/robots.txt"
curl -I "$BASE/llms.txt"
curl -I "$BASE/sitemap.xml"
curl -I "$BASE/sitemap_index.xml"
curl -I "$BASE/favicon.ico"
curl -I "$BASE/og-default.jpg"

curl -s "$BASE/robots.txt" | grep -i "Sitemap:"
curl -s "$BASE/sitemap.xml" | grep -Ei "wp-admin|admin|noindex|staging|workers.dev"
curl -s "$BASE/llms.txt" | grep -Ei "clinical pressure|thermal imaging|motion transfer|90 nights|120 nights|120h|GREENGUARD|cure|permanent|medical brace|licensed in|staff chiropractor"
curl -s "$BASE/best-mattress-for-back-pain-2026/" | grep -Ei "cure|permanent|shuts it down|medical brace|violently|inflammation|clinical|licensed in|staff chiropractor|GREENGUARD"
```

Expected:

- Core endpoints return 200 or clean redirects.
- `/llms.txt` returns 200.
- Sitemap resolves and contains final production URLs only.
- No admin/staging/internal/noindex URLs appear in sitemap.
- No unsupported medical, testing, reviewer, or certification claims appear in `llms.txt` or pain pages.

## Schema Validation

Validate each JSON-LD block with:

- Google Rich Results Test
- Schema.org validator
- Rank Math schema preview, if used

Do not deploy `reviewedBy` or `MedicalWebPage` unless reviewer/medical approval is documented.
