# CRO, Affiliate, And Deal Routing Plan

CTA hierarchy:

1. Check price / see current deal
2. Read full review
3. Compare alternatives
4. View methodology/disclosure

Rules:

- Add affiliate disclosure before first commercial CTA.
- Deal claims require current verification.
- Comparison pages need a top recommendation box.
- Every recommendation needs a "who should avoid" counterweight.
