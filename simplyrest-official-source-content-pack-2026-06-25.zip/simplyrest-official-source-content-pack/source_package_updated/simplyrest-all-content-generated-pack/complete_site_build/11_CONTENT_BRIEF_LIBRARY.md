# Content Brief Library

Every brief must include:

- target URL
- target query
- user job
- direct answer
- primary recommendation
- alternatives
- proof required
- claim risks
- internal links
- CTA plan
- schema plan
- QA checklist

Use existing package pages as the first brief set.
