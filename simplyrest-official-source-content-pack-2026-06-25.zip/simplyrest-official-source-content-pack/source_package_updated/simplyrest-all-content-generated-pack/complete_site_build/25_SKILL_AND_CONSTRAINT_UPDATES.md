# Skill And Constraint Updates

Suggested durable constraints:

- Do not claim firsthand testing unless internal testing evidence exists.
- Do not publish current-year deal pages without current deal verification.
- Do not recommend page deletion without performance/search/link/revenue/replacement review.
- Every Simply Rest commercial page needs who should buy, who should avoid, tradeoffs, evidence, and product-routing logic.
- Every health-sensitive page needs cautious informational framing and disclaimer guidance.

No live skill was created or applied from this package; this is a proposed update record only.
