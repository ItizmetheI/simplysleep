# Risks And Approvals

Human approvals required:

- WordPress publish/update
- redirect/canonical decisions
- reviewer attribution and schema
- certification claims
- deal/pricing claims
- medical/sleep-health claims
- robots.txt changes
- llms.txt publish

Top risks:

- URL cannibalization
- stale prices/deals
- unsupported medical language
- empty/weak hubs
- comparison pages without proof
