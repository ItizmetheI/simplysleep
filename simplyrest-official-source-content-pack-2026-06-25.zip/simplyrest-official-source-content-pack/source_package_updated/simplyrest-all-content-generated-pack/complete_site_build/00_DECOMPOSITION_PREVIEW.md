# Decomposition Preview

Date: 2026-06-18

Goal: Upgrade Simply Rest from a MattressNut-style batch package into a complete site-build system.

Scope: Full SimplyRest.com site system: strategy, IA, templates, reviews, comparisons, deal architecture, sleep health, technical SEO, analytics, QA, and launch runbook.

Loop type: Fleet loop standard, implemented as a human-approval-ready package.

Artifacts produced: 25 complete-site artifacts plus the existing WordPress implementation package.

Human approval gates: publishing, live WordPress edits, claim approval, reviewer approval, redirects/canonicals, robots changes, schema deployment, spend, and external messages.
