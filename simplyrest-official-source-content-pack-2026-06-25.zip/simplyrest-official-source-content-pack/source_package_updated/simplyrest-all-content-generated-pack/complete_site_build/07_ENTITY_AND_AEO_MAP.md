# Entity And AEO Map

Core entities:

- Simply Rest
- Amerisleep AS2, AS3, AS5, AS6 Black Series, Organica
- Zoma, Vaya
- competitor products from the approved comparison queue
- mattress types, sleeper types, materials, certifications, deal events

Required answer blocks:

- Best overall
- Best for / not for
- Top recommendation
- Choose A if / choose B if
- Tradeoff summary
- FAQ answer

AEO rule:

Every commercial page must make one concise recommendation and explain the tradeoff.
