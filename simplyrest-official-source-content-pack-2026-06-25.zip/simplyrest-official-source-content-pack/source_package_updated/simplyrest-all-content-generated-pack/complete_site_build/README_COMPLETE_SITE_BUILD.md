# Complete Site Build Layer

This folder upgrades the Simply Rest handoff from a page package into the 25-artifact complete-site build system requested by the attached Simply Rest Complete Site Build Loop.

Use this alongside:

- `../implementation/`
- `../package/`
- `../trackers/`
- `../qa/`

This is still a human-approval package. It does not publish, approve claims, or change live systems.
