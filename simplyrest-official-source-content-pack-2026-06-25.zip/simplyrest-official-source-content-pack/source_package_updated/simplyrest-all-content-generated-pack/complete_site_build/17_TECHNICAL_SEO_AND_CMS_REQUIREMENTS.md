# Technical SEO And CMS Requirements

CMS fields:

- title
- slug
- canonical
- meta title
- meta description
- author
- reviewer approval status
- product facts
- FAQ
- schema JSON
- last verified
- next refresh
- affiliate disclosure

Technical requirements:

- working sitemap
- root llms.txt
- clean robots.txt
- no admin/staging URLs indexed
- schema matches visible content
- redirects/canonicals resolved before publish
