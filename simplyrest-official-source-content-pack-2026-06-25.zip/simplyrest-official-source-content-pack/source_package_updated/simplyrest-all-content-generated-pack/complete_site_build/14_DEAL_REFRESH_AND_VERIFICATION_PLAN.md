# Deal Refresh And Verification Plan

Deal pages require:

- last updated date
- merchant/source
- discount/coupon terms
- expiration if known
- current verification date
- fine print
- owner
- next refresh date

Auto-fail:

- expired deal shown as current
- current-year title without current verification
- no disclosure
