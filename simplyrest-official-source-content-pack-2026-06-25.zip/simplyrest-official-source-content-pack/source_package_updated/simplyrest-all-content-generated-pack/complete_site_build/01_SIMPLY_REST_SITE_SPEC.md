# Simply Rest Site Spec

Simply Rest should be a consumer-first sleep decision engine, not a generic affiliate blog.

Primary lanes:

- Mattress guides
- Mattress reviews
- Mattress comparisons
- Mattress sales and deal pages
- Sleep health education
- Mattress resources
- Bedding and accessory guides

Editorial promise:

- Direct answers
- Clear tradeoffs
- Evidence-led recommendations
- Claim-safe language
- Current deal/product verification
- Useful commercial routing without overwhelming trust

Launch system already included:

- 12 best-of/persona pages
- 6 review pages
- 24 comparison pages
- 4 foundation trust pages
- llms.txt
- QA/evidence registers
