# Page Type Template Library

Included templates:

- Homepage requirements
- Best mattress hub
- Best-of category page
- Product review page
- Product comparison page
- Sales/deal page
- Sleep health page
- Mattress resource guide
- Bedding/accessory guide
- Author/reviewer page
- Methodology page
- Disclosure module

The live package includes concrete drafts for best-of, review, comparison, methodology, reviewers, editorial policy, disclosure, llms, and QA.
