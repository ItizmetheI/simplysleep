# Analytics And Tracking Plan

Track:

- organic sessions by page type
- clicks to affiliate/merchant CTAs
- review page entrances
- comparison page assists
- AI citation appearances
- indexed URL count
- sitemap errors
- stale product facts
- deal refresh compliance

Weekly:

- check top pages
- check new URLs indexed
- check CTA clicks
- run AI citation spot checks
