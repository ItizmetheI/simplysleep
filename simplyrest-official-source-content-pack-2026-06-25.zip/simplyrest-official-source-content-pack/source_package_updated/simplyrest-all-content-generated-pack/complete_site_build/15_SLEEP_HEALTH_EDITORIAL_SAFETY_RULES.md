# Sleep Health Editorial Safety Rules

Sleep health content must be informational, not diagnostic.

Blocked without approval:

- cures, treats, prevents, diagnoses
- medical brace language
- permanent pain relief
- inflammation/disc claims
- doctor/chiropractor schema without proof

Use:

- may help with mattress-related discomfort
- support and alignment potential
- pressure relief for some sleepers
- speak with a qualified professional when pain persists
