# Design System And Component Requirements

Required components:

- Top recommendation box
- Product card
- Review card
- Comparison table
- Best for / not for module
- Pros/cons module
- Deal verification box
- Expert/reviewer box
- Methodology/disclosure module
- FAQ block
- Related content links

Mobile rule:

Tables must be readable, scrollable, and not collapse into unusable text.
