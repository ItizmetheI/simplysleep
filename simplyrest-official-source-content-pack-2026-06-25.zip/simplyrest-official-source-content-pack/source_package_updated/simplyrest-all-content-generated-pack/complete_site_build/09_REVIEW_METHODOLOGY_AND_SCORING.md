# Review Methodology And Scoring

Do not publish scores until scoring is approved and source-backed.

Current methodology uses qualitative fit criteria:

- comfort fit
- support and alignment potential
- pressure relief potential
- cooling/breathability
- motion isolation
- edge support
- ease of movement
- materials
- value
- trial/warranty/returns

Testing claims are blocked unless actual Simply Rest testing documentation exists.
