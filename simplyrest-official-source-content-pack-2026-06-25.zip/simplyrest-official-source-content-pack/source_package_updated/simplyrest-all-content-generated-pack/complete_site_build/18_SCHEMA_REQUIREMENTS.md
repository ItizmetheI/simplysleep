# Schema Requirements

Baseline:

- WebPage
- Article
- BreadcrumbList
- FAQPage when FAQ is visible
- ItemList for ranked lists
- Review only for actual product review pages

Do not deploy by default:

- reviewedBy without approval
- MedicalWebPage without approval
- AggregateRating without source
- Product/Offer with stale price or availability
