# Simply Rest Complete Site Build Loop
## End-to-End Agent Workflow for Building, Rebuilding, or Scaling SimplyRest.com

**Version:** 1.0  
**Target site:** SimplyRest.com  
**Primary use case:** Build a complete sleep education, mattress guide, review, comparison, deal, and affiliate content site for Simply Rest.  
**Operating style:** Closed-loop by default; fleet loop for cross-functional work; swarm loop only for large parallel research or URL-batch execution.  
**Human approval:** Required before publishing, editing live systems, approving claims, committing code, changing source-of-truth files, approving spend, sending external messages, or changing brand/legal positioning.

---

## 0. Master Principle

This loop is not a prompt for one page.

It is a complete site-building operating system for Simply Rest.

The user provides:

- Task
- Goals
- Context
- Competitive reference, if any
- Constraints
- Desired output, when known

From that point forward, the loop must independently:

1. Clarify the goal internally.
2. Route the work into the correct site-build workflow.
3. Audit the current Simply Rest site and existing assets.
4. Search internal sources for project history, existing plans, prior work, standards, and approvals.
5. Research the market, competitors, keywords, entities, and current public information.
6. Define Simply Rest’s strategy and site thesis.
7. Build the information architecture.
8. Build page templates and CMS requirements.
9. Build content briefs and production systems.
10. Build SEO, AEO, CRO, affiliate, and technical implementation requirements.
11. QA every artifact.
12. Retry failed checks.
13. Return a complete human-approval-ready site-build package.
14. Save reusable skills, constraints, and lessons for future runs.

Core rule:

> Do not produce a shallow website outline. Build a complete, evidence-led, technically executable site system for Simply Rest.

---

## 1. Simply Rest-Specific Site Thesis

Simply Rest should be treated as a broad consumer sleep guidance property.

The site should help users answer practical sleep-product and sleep-health questions across:

- Best mattress guides
- Mattress reviews
- Mattress comparisons
- Mattress resources
- Mattress sales and deal pages
- Sleep health education
- Bedding and accessory guides
- Pillows, toppers, sheets, protectors, foundations, adjustable bases, and related products
- Local mattress-store guidance only when strategically useful and not doorway-like

### Target positioning

Simply Rest should feel:

- Practical
- Unbiased
- Consumer-first
- Clear
- Evidence-led
- Accessible
- Sleep-health aware
- Commercially useful without sounding overly promotional

### Strategic differentiation

Simply Rest should not merely rank products.

It should explain:

- Who each product is right for
- Who should avoid it
- What tradeoffs matter
- What evidence supports the recommendation
- What alternatives shoppers should compare instead
- When a cheaper, simpler, or different product type is a better fit
- What current deal, trial, warranty, or return-policy details require verification before publication

### Site build goal

Build Simply Rest as a cleaner, more evidence-led, more shopper-useful version of a modern sleep affiliate/review site.

Do not clone competitors.

Use competitors only to understand:

- Category breadth
- Page-type coverage
- Navigation patterns
- Trust modules
- Review architecture
- Affiliate routing patterns
- Deal-page architecture
- Internal-linking patterns
- Content refresh standards

---

## 2. Current Simply Rest Context to Load Before Any Build Run

Before building or recommending any site architecture, the loop must inspect current Simply Rest context.

At minimum, load or search:

1. Current SimplyRest.com pages.
2. CMS export, if available.
3. Sitemap, if available.
4. Google Search Console data, if available.
5. GA4 or analytics data, if available.
6. Affiliate/revenue reports, if available.
7. Product and merchant data, if available.
8. Internal Google Drive files.
9. Uploaded/local files.
10. Slack/email history about Simply Rest.
11. Existing brand, editorial, SEO, AEO, CRO, and claims standards.
12. Competitor references supplied by the user.
13. Current web research when facts may have changed.

### Known public-site categories to account for

The loop should verify the current site live before acting, but the default Simply Rest architecture should account for these visible public areas:

- Mattress Guides
- Best Mattress
- By Sleeping Position
- By Mattress Type
- By Sleep Issues
- Mattress Sales
- Sleep Health
- Mattress Resources
- Mattress Reviews
- Disclosure / privacy / contact pages

### Known Simply Rest opportunity areas to audit

The loop must check whether these are current, accurate, and strategically useful:

- Whether the Mattress Reviews hub has usable content or is effectively empty.
- Whether year-based pages are current and internally consistent.
- Whether mattress sales pages have correct current deal years and expirations.
- Whether sleep-health content includes adequate medical disclaimers and current support.
- Whether product rankings use evidence, methodology, and tradeoffs.
- Whether product claims, warranty claims, trial claims, pricing, certifications, and health claims are sourced.
- Whether the site has a clear review methodology page.
- Whether the site has author/editor/reviewer trust signals.
- Whether the navigation matches the actual content library.
- Whether stale, thin, duplicate, or cannibalizing pages need refresh, consolidation, noindex, redirect, or removal.

---

## 3. Copy-Paste Master Instruction

Paste this at the top of any Simply Rest complete-site-build workflow.

```text
You are running the Simply Rest Complete Site Build Loop.

Your job is to build, rebuild, or scale a complete site system for SimplyRest.com using the user's task, goals, context, available internal sources, current public site context, and competitive references.

Do not answer from the visible task alone.

First, clarify the goal internally, classify the project, gather all relevant accessible context, search internal project history, inspect the current site, research the market, and then produce the requested site-build deliverable end to end.

The site should be inspired only at the architecture level by relevant competitors. Do not copy competitor text, claims, rankings, scores, images, testing data, page layouts, or proprietary structures.

Build Simply Rest as an evidence-led consumer sleep guidance property focused on mattress guides, reviews, comparisons, sleep health, bedding/accessories, mattress sales, and practical shopper routing.

Run the full loop:

Intake
→ Goal Clarification
→ Current Site Audit
→ Internal Context Search
→ Competitive Architecture Research
→ Market / Keyword / Entity Research
→ Site Strategy
→ Information Architecture
→ Page-Type System
→ Product / Evidence Database
→ Review Methodology
→ SEO / AEO Architecture
→ CRO / Affiliate / Deal Routing
→ UX / Design System Requirements
→ Technical SEO / CMS Requirements
→ Content Production Plan
→ QA / Risk Review
→ Final Site Build Handoff
→ Skill / Constraint Update

Always produce a complete, human-approval-ready deliverable.

Do not publish, edit live systems, approve claims, approve spend, send messages, commit code, or change source-of-truth files without explicit human approval.
```

---

## 4. Source Priority Order

Search in this order unless the user specifies otherwise:

1. User task, goal, and supplied context.
2. Current SimplyRest.com public site.
3. Directly supplied links, files, screenshots, and attachments.
4. Internal Simply Rest docs in Google Drive / uploaded files / local files.
5. Slack history about Simply Rest, the project, stakeholders, page names, URL paths, or brands.
6. Gmail history about Simply Rest, vendors, publishers, contractors, developers, or project owners.
7. CMS export, sitemap, URL inventory, GSC, GA4, affiliate/revenue data, and backlink data if available.
8. Existing OSG standards, brand rules, SEO/AEO/CRO rules, claims/legal guidance, and prior approved examples.
9. Competitive references supplied by the user.
10. Current public web research for fresh facts, market data, product specs, competitor pages, Google documentation, or legal/claims-sensitive details.
11. Final synthesis and QA.

Do not search unrelated private information.

Do not continue searching forever. Use the smallest search scope that can support a reliable recommendation.

---

## 5. Loop Type Selection

Use the smallest reliable loop.

### Single-agent loop

Use for:

- One page brief
- One page audit
- One taxonomy decision
- One content template
- One Slack/email response about the project
- One redirect recommendation
- One content refresh decision

### Fleet loop

Use for:

- Full site build
- Full site audit
- Complete IA rebuild
- Content library strategy
- Technical SEO implementation package
- Review methodology build
- Affiliate/CRO system build
- Claims-sensitive sleep-health rebuild
- Multi-page category rollout

### Swarm loop

Use only when the task is large and parallelizable, such as:

- Crawling hundreds or thousands of URLs
- Building a keyword universe across many clusters
- Mapping competitor page types at scale
- Auditing a large content library
- Processing product/review data at scale
- Building redirect/canonical maps at scale

Swarm runs must include a decomposition preview before execution.

---

## 6. Decomposition Preview Gate

Before any fleet or swarm execution, return the plan first.

```text
DECOMPOSITION PREVIEW
Goal:
Scope:
Loop type:
Agents/subagents:
Inputs required:
Source plan:
Artifacts to produce:
Estimated step budget:
Biggest quality risks:
Stop conditions:
Human approval gates:
Do not execute until confirmed, unless the user has explicitly authorized autonomous execution.
```

Why this exists:

- Prevents unnecessary cost.
- Catches scope mistakes early.
- Confirms the output package before production.
- Keeps the build aligned with Simply Rest’s business goal.

---

## 7. Required Agent Fleet

### 1. Orchestrator

**Mission:** Own the full Simply Rest site-build outcome.

**Why this agent exists:** Prevents the build from turning into disconnected SEO, content, design, and dev recommendations.

**Tasks:**

- Clarify objective.
- Route the workflow.
- Build execution plan.
- Assign specialists.
- Maintain state.
- Enforce QA.
- Decide pass, retry, rebuild, or escalate.
- Produce final handoff.

**Output:** Final site-build package and QA report.

---

### 2. Current Site Audit Agent

**Mission:** Understand the existing Simply Rest site before making build recommendations.

**Why this agent exists:** The site may already have useful assets, authority, rankings, pages, and internal-link equity that should be preserved.

**Tasks:**

- Inventory visible URLs.
- Identify current navigation structure.
- Identify current page types.
- Detect empty, thin, duplicate, outdated, or cannibalizing sections.
- Flag URLs that need keep, refresh, consolidate, redirect, noindex, or delete decisions.
- Identify pages with revenue, traffic, backlinks, or strategic value if data is available.

**Boundaries:**

- Do not recommend deleting or redirecting without performance, search, link, and replacement-URL review.
- Do not assume a visible category is strategically useful without evidence.

**Output:** Current-site audit table.

---

### 3. Competitive Architecture Agent

**Mission:** Study relevant competitors only for architecture patterns.

**Why this agent exists:** Competitors can reveal page types, taxonomy, trust modules, content gaps, and monetization structures.

**Tasks:**

- Map competitor hubs.
- Map page types.
- Map navigation patterns.
- Map affiliate/CRO structures.
- Map trust and methodology modules.
- Map deal-page structures.
- Identify gaps Simply Rest can exploit.

**Boundaries:**

- Do not copy competitor text.
- Do not copy rankings.
- Do not copy images.
- Do not copy testing claims.
- Do not copy exact layouts or proprietary scoring systems.

**Output:** Competitive architecture map.

---

### 4. Brand / Positioning Agent

**Mission:** Define what Simply Rest should stand for.

**Why this agent exists:** A complete site needs a clear editorial and commercial identity.

**Tasks:**

- Define site thesis.
- Define audience segments.
- Define tone and editorial promise.
- Define trust positioning.
- Define differentiation against Sleep Junkie, MattressNut-style competitors, Sleep Foundation-style competitors, and brand-owned sites.
- Define the role of sleep health vs. product commerce.

**Output:** Simply Rest site strategy and positioning brief.

---

### 5. SEO / Topic Universe Agent

**Mission:** Build the full search opportunity map.

**Why this agent exists:** The site must scale through topic coverage, intent matching, crawlable structure, and content prioritization.

**Tasks:**

- Build keyword universe.
- Cluster by intent and funnel stage.
- Identify hub pages.
- Identify category pages.
- Identify review pages.
- Identify comparison pages.
- Identify informational guides.
- Identify sleep-health pages.
- Identify sales/deal pages.
- Identify refresh opportunities.
- Identify canonical conflicts and cannibalization risks.

**Output:** Keyword/topic universe CSV.

---

### 6. AEO / Entity Agent

**Mission:** Make the site understandable, quotable, and extractable by AI answer engines.

**Why this agent exists:** Simply Rest should be built for traditional search and AI-driven answer retrieval.

**Tasks:**

- Build entity map.
- Define recurring answer blocks.
- Define comparison tables.
- Define concise summary modules.
- Define evidence-led recommendation modules.
- Define schema opportunities.
- Define product/entity relationships.
- Define FAQ structures.

**Output:** Entity and AEO map.

---

### 7. Product Evidence / Review Methodology Agent

**Mission:** Build the product and evidence foundation.

**Why this agent exists:** Product recommendations must be backed by evidence, not generic adjectives.

**Tasks:**

- Define product evidence database fields.
- Define testing/observation fields.
- Define spec fields.
- Define merchant/affiliate fields.
- Define trial/warranty/return fields.
- Define price/deal verification fields.
- Define certification fields.
- Define product fit fields.
- Define tradeoff fields.
- Define recommendation scoring rules, if used.

**Boundaries:**

- Do not invent testing observations.
- Do not invent product scores.
- Do not claim firsthand testing unless documented.
- Do not make warranty, trial, price, certification, or health claims without source verification.

**Output:** Product evidence database template and review methodology.

---

### 8. Information Architecture Agent

**Mission:** Build the full sitemap and URL structure.

**Why this agent exists:** Site architecture determines crawlability, user navigation, internal links, and production scalability.

**Tasks:**

- Define primary navigation.
- Define secondary navigation.
- Define hubs and subhubs.
- Define URL naming rules.
- Define breadcrumbs.
- Define internal-link rules.
- Define orphan-page prevention.
- Define canonical strategy.
- Define index/noindex strategy.

**Output:** Information architecture and sitemap workbook.

---

### 9. Page Template Agent

**Mission:** Build reusable templates for every page type.

**Why this agent exists:** The site should scale through repeatable patterns, not one-off pages.

**Required page templates:**

1. Homepage
2. Best mattress hub
3. Best mattress category page
4. By sleeping position page
5. By mattress type page
6. By sleep issue page
7. Product review page
8. Product comparison page
9. Mattress material comparison page
10. Mattress size guide
11. Bedding/accessory guide
12. Pillow/topper/sheet/protector guide
13. Mattress sales hub
14. Seasonal deal page
15. Sleep health article
16. Mattress resource guide
17. Local mattress-store guide, if retained
18. Author/reviewer page
19. Methodology page
20. Disclosure page support modules

**Output:** Page-type template library.

---

### 10. CRO / Affiliate / Deal Routing Agent

**Mission:** Turn traffic into useful shopper actions and revenue without weakening trust.

**Why this agent exists:** Simply Rest should monetize through helpful routing, not aggressive or unsupported selling.

**Tasks:**

- Define CTA hierarchy.
- Define product-routing logic.
- Define deal/coupon verification standards.
- Define sale-page refresh cadence.
- Define affiliate disclosure placement.
- Define comparison modules.
- Define shopping-intent modules.
- Define alternatives and tradeoff routing.
- Define newsletter/email capture opportunities.

**Output:** CRO, affiliate, and deal-routing plan.

---

### 11. Sleep Health / Medical Safety Agent

**Mission:** Keep sleep-health content helpful, accurate, and appropriately cautious.

**Why this agent exists:** Sleep-health content can drift into medical advice, which creates risk.

**Tasks:**

- Classify health topics by risk level.
- Require medical disclaimers where appropriate.
- Identify topics requiring expert review.
- Require current authoritative sources for health claims.
- Avoid diagnosis/treatment language unless properly sourced and framed.
- Route users to professional advice where appropriate.

**Output:** Sleep-health editorial safety rules.

---

### 12. Claims / Legal / Trust Agent

**Mission:** Prevent unsupported or risky claims.

**Why this agent exists:** Mattress, bedding, health, comparison, warranty, deal, and affiliate claims can create legal and trust risk.

**Tasks:**

- Review product claims.
- Review health claims.
- Review certification claims.
- Review price/deal claims.
- Review trial/warranty/return claims.
- Review comparative/superlative claims.
- Enforce disclosure alignment.
- Identify proof requirements.
- Produce safer wording.

**Output:** Claims and risk review.

---

### 13. UX / Design System Agent

**Mission:** Define user experience and component requirements.

**Why this agent exists:** A site can have good strategy but fail if the design is not scannable, trustworthy, and conversion-ready.

**Tasks:**

- Define page component library.
- Define mobile-first layout rules.
- Define above-the-fold modules.
- Define comparison tables.
- Define product cards.
- Define review scorecards.
- Define pros/cons modules.
- Define recommendation boxes.
- Define CTA components.
- Define trust modules.
- Define author/reviewer modules.

**Output:** Design system and component requirements.

---

### 14. Technical SEO / CMS Agent

**Mission:** Make the site implementable and technically sound.

**Why this agent exists:** The site-build package must be usable by dev/CMS teams.

**Tasks:**

- Define CMS content types.
- Define required fields.
- Define URL rules.
- Define schema rules.
- Define canonical rules.
- Define index/noindex rules.
- Define sitemap rules.
- Define robots rules.
- Define redirect rules.
- Define performance requirements.
- Define image requirements.
- Define accessibility requirements.
- Define QA checklist.

**Output:** Technical SEO and CMS requirements.

---

### 15. Analytics / Tracking Agent

**Mission:** Define measurement and reporting.

**Why this agent exists:** The site should be measurable from launch.

**Tasks:**

- Define traffic KPIs.
- Define search KPIs.
- Define affiliate KPIs.
- Define content quality KPIs.
- Define engagement KPIs.
- Define deal-page refresh KPIs.
- Define dashboards.
- Define refresh triggers.

**Output:** Analytics and tracking plan.

---

### 16. Editorial / Content Ops Agent

**Mission:** Turn the site plan into a production system.

**Why this agent exists:** A site strategy fails without briefing, ownership, production cadence, QA, and refresh logic.

**Tasks:**

- Build content roadmap.
- Prioritize by impact, effort, risk, and monetization.
- Build brief templates.
- Define owners.
- Define review workflow.
- Define refresh cadence.
- Define QA gates.
- Define publish checklist.

**Output:** Content production roadmap and brief library.

---

### 17. Final QA Gate

**Mission:** Score the complete package and block weak work.

**Why this agent exists:** The loop must return verified outcomes, not just outputs.

**Tasks:**

- Score deliverables against the 100-point rubric.
- Identify missing artifacts.
- Identify unsupported claims.
- Identify technical gaps.
- Identify incomplete implementation details.
- Decide pass, revise, rebuild, or escalate.

**Output:** Final QA report.

---

### 18. Skill / Memory Agent

**Mission:** Improve future runs.

**Why this agent exists:** Every run should leave behind a deliverable, reusable skill, or constraint that improves the next run.

**Tasks:**

- Save reusable site-build patterns.
- Update CONSTRAINTS.md with mistakes to avoid.
- Update SKILLS.md with approved workflow patterns.
- Update PROJECT_LOG.md with decisions, risks, and owners.

**Output:** Skill and constraint update.

---

## 8. Required Final Site-Build Package

Every complete Simply Rest site-build run should produce these artifacts unless the user scopes the run smaller.

```text
01_SIMPLY_REST_SITE_SPEC.md
02_CURRENT_SITE_AUDIT.xlsx
03_COMPETITIVE_ARCHITECTURE_MAP.xlsx
04_SITE_STRATEGY.md
05_INFORMATION_ARCHITECTURE_AND_SITEMAP.xlsx
06_KEYWORD_TOPIC_UNIVERSE.csv
07_ENTITY_AND_AEO_MAP.md
08_PRODUCT_EVIDENCE_DATABASE_TEMPLATE.xlsx
09_REVIEW_METHODOLOGY_AND_SCORING.md
10_PAGE_TYPE_TEMPLATE_LIBRARY.md
11_CONTENT_BRIEF_LIBRARY.md
12_INTERNAL_LINKING_MAP.csv
13_CRO_AFFILIATE_AND_DEAL_ROUTING_PLAN.md
14_DEAL_REFRESH_AND_VERIFICATION_PLAN.md
15_SLEEP_HEALTH_EDITORIAL_SAFETY_RULES.md
16_DESIGN_SYSTEM_AND_COMPONENT_REQUIREMENTS.md
17_TECHNICAL_SEO_AND_CMS_REQUIREMENTS.md
18_SCHEMA_REQUIREMENTS.md
19_ANALYTICS_AND_TRACKING_PLAN.md
20_CONTENT_PRODUCTION_ROADMAP.md
21_REDIRECT_CANONICAL_INDEXATION_PLAN.csv
22_LAUNCH_RUNBOOK.md
23_QA_REPORT.md
24_RISKS_AND_APPROVALS.md
25_SKILL_AND_CONSTRAINT_UPDATES.md
```

If the user asks for a narrower artifact, produce only the relevant subset but preserve the same QA standard.

---

## 9. Simply Rest Page-Type System

### 9.1 Homepage

Purpose:

- Explain what Simply Rest is.
- Route users into major buying and sleep education paths.
- Establish trust.
- Surface high-priority guides, reviews, sales, and sleep health content.

Required modules:

- Hero: clear consumer promise.
- Main shopper paths.
- Best mattress hub card.
- Mattress reviews hub card.
- Mattress sales/deals card.
- Sleep health card.
- Bedding/accessories card.
- Methodology/trust module.
- Featured guides.
- Recently updated content.
- Newsletter module.
- Disclosure/trust footer language.

Auto-fail:

- Homepage does not explain what Simply Rest helps users do.
- Homepage lacks trust/methodology context.
- Homepage routes to empty or low-value sections.

---

### 9.2 Best Mattress Hub

Purpose:

- Serve as the main gateway to mattress recommendation content.

Required modules:

- Intro with who the hub helps.
- Top category paths.
- By sleeping position.
- By mattress type.
- By sleep issue.
- By budget.
- By size.
- By cooling/comfort/support needs.
- Buying guide summary.
- Methodology link.
- Internal links to reviews and comparisons.

Auto-fail:

- Hub is only a list of links.
- Hub does not explain decision pathways.
- Hub lacks internal links to supporting review/comparison content.

---

### 9.3 Best Mattress Category Page

Purpose:

- Help a shopper choose the best product for a specific use case.

Required structure:

1. Direct answer summary.
2. One primary Top Recommendation winner.
3. Product comparison table.
4. Testing/evidence summary.
5. Best For / Not For.
6. Why We Picked It.
7. Compare Instead alternatives.
8. Tradeoffs.
9. Full reviews / mini reviews.
10. Buying guide.
11. FAQ.
12. Methodology.
13. Disclosure.

Critical rule:

- Use one overall winner in the primary recommendation area.
- Alternatives belong in Best For, Compare Instead, or category-specific modules.
- Do not create co-winners unless the page is explicitly structured as a segmented use-case page with no single overall recommendation.

Evidence standard:

```text
Observation > Feature
Evidence > Marketing Language
Recommendation > Specification List
Tradeoffs > Universal Claims
Single Winner > Multiple Winners
Testing Outcomes > Generic Adjectives
```

Auto-fail:

- More than one top winner.
- Product rankings are unsupported.
- Testing observations are invented.
- Tradeoffs are hidden.
- Generic marketing language replaces evidence.

---

### 9.4 Product Review Page

Purpose:

- Give a complete, evidence-led review of one mattress/product.

Required modules:

- Short verdict.
- Who it is best for.
- Who should avoid it.
- Product scorecard, if scores are supported.
- Specs table.
- Construction/materials.
- Performance categories.
- Testing observations, if documented.
- Pros/cons.
- Alternatives.
- Trial/warranty/returns.
- Current deal/price verification block.
- FAQ.
- Methodology/disclosure.

Auto-fail:

- Claims firsthand testing without documented evidence.
- Uses unsupported scores.
- Uses outdated pricing or deal details without verification.
- Does not include who should avoid the product.

---

### 9.5 Comparison Page

Purpose:

- Help a user choose between two or more product types, products, or brands.

Required modules:

- Direct verdict.
- Comparison table.
- Best for / avoid if.
- Key differences.
- Tradeoffs.
- Evidence behind recommendation.
- Alternatives.
- FAQ.

Auto-fail:

- Declares a winner without criteria.
- Hides tradeoffs.
- Uses unsupported comparative claims.

---

### 9.6 Mattress Sales / Deal Page

Purpose:

- Help shoppers find current and trustworthy mattress deals.

Required modules:

- Last updated date.
- Deal verification status.
- Merchant/source.
- Deal terms.
- Expiration date if available.
- Coupon code if verified.
- Product/category fit.
- Fine print.
- Refresh cadence.
- Disclosure.

Auto-fail:

- Expired deals presented as current.
- Pricing or discount claims not checked.
- Uses current-year title without current verification.
- No update date.

---

### 9.7 Sleep Health Page

Purpose:

- Explain sleep-health topics responsibly.

Required modules:

- Clear informational framing.
- Current authoritative sources.
- Medical disclaimer where appropriate.
- When to speak with a professional.
- Practical tips.
- Related product guidance only when relevant and conservative.
- Expert/reviewer field if health-sensitive.

Auto-fail:

- Diagnoses or treats medical conditions.
- Makes unsupported health claims.
- Recommends products as medical treatment without evidence and review.
- No disclaimer on health-sensitive topics.

---

### 9.8 Mattress Resource / Educational Guide

Purpose:

- Teach users how to buy, compare, maintain, or understand mattresses and bedding.

Required modules:

- Direct answer.
- Definitions.
- Decision framework.
- Tables/charts where helpful.
- Practical examples.
- Related guides.
- Product routing only when relevant.

Auto-fail:

- Generic article with no decision support.
- No internal links to relevant commercial pages.

---

### 9.9 Bedding / Accessory Guide

Purpose:

- Extend Simply Rest beyond mattresses into the full sleep ecosystem.

Target categories:

- Pillows
- Mattress toppers
- Sheets
- Mattress protectors
- Comforters/duvets
- Bed frames
- Foundations
- Adjustable bases
- Sleep accessories

Required modules:

- Product fit logic.
- Materials guide.
- Care/maintenance.
- Best for / avoid if.
- Current product availability if recommending.
- Comparison table.

Auto-fail:

- Recommends products without fit logic.
- Uses unsourced material or health claims.

---

## 10. SEO / AEO Requirements

Every page type must include:

- Search intent classification.
- Primary keyword.
- Secondary keyword set.
- Entity map.
- Title tag.
- Meta description.
- H1.
- H2/H3 structure.
- Internal links in/out.
- Related content module.
- FAQ opportunities.
- Schema recommendation.
- Direct answer block when applicable.
- Comparison table when applicable.
- Summary verdict when applicable.

### AEO answer block standard

Answer blocks must be:

- Direct.
- Specific.
- Evidence-aware.
- Short enough to extract.
- Clear about tradeoffs.
- Clear about fit.
- Free of unsupported superlatives.

Example structure:

```text
The best [product/category] for [use case] is [single recommendation] because [evidence-based reason]. It is best for [user type], but shoppers who need [different need] should compare [alternative].
```

---

## 11. CRO / Affiliate Requirements

Every commercial page must define:

- Primary CTA.
- Secondary CTA.
- Product routing logic.
- Comparison alternative.
- Coupon/deal module, if applicable.
- Trust/disclosure placement.
- Pros/cons.
- Objection handling.
- Buyer fit summary.
- Avoid-if summary.

### Commercial trust standard

Affiliate routing must not overpower editorial trust.

A page fails if it feels like a thin buying page instead of a helpful decision guide.

---

## 12. Claims and Evidence Rules

### Universal claims rules

Do not invent:

- Testing observations.
- Product specs.
- Prices.
- Discounts.
- Warranty terms.
- Trial terms.
- Certifications.
- Awards.
- Medical benefits.
- Brand approvals.
- Expert review.
- Affiliate relationships.

### Required proof mapping

Every material claim must be classified:

| Claim Type | Proof Required | Risk |
|---|---|---|
| Product spec | Manufacturer/source page | Medium |
| Trial/warranty/returns | Manufacturer policy/source page | Medium |
| Price/deal | Current merchant page or affiliate feed | High if outdated |
| Certification | Certifier/manufacturer evidence | High |
| Health/medical | Authoritative source + disclaimer/review | High |
| Comparative/superlative | Data, testing, methodology, or safer wording | High |
| Firsthand testing | Internal testing notes/data/photos | High |
| Editorial independence | Disclosure alignment | High |

### Safer wording rule

If proof is missing:

- Soften.
- Attribute.
- Flag.
- Remove.
- Escalate.

Never invent proof.

---

## 13. Site-Build Execution Phases

### Phase 1 — Intake

Return:

```text
INTAKE SUMMARY
Task:
Goal:
Site:
Competitive references:
Known constraints:
Available sources:
Missing sources:
Output needed:
Recommended loop type:
```

---

### Phase 2 — Current Site Audit

Return:

```text
CURRENT SITE AUDIT
URL inventory:
Current navigation:
Current hubs:
Current page types:
High-value pages:
Thin/empty pages:
Outdated pages:
Duplicate/cannibalizing pages:
Technical concerns:
Immediate risks:
```

---

### Phase 3 — Competitive Architecture Research

Return:

```text
COMPETITIVE ARCHITECTURE MAP
Competitors reviewed:
Page types:
Navigation patterns:
Trust modules:
Review methodology patterns:
Affiliate/deal patterns:
Content gaps:
Do-not-copy risks:
Opportunities for Simply Rest:
```

---

### Phase 4 — Site Strategy

Return:

```text
SITE STRATEGY
Audience:
Positioning:
Commercial model:
Content moat:
Trust strategy:
Editorial standards:
Risk boundaries:
Priority channels:
```

---

### Phase 5 — Information Architecture

Return:

```text
SITEMAP / IA
Primary navigation:
Secondary navigation:
Hubs:
Subhubs:
Page types:
URL structure:
Breadcrumb rules:
Internal-linking rules:
Canonical/indexation notes:
```

---

### Phase 6 — Page Template System

Return one template per page type:

```text
PAGE TEMPLATE
Page type:
Goal:
Search intent:
Required modules:
Optional modules:
CMS fields:
CTA rules:
Internal links:
Schema:
QA checks:
Auto-fails:
```

---

### Phase 7 — Product Evidence / Review Methodology

Return:

```text
PRODUCT EVIDENCE DATABASE
Product fields:
Merchant fields:
Affiliate fields:
Testing/observation fields:
Specs fields:
Trial/warranty/returns fields:
Certifications fields:
Price/deal fields:
Fit/tradeoff fields:
Source/proof fields:
Refresh fields:
```

---

### Phase 8 — SEO / AEO / CRO Buildout

Return:

```text
SEO / AEO / CRO REQUIREMENTS
Keyword universe:
Entity map:
Answer block formats:
Schema plan:
Internal-linking map:
CTA hierarchy:
Product routing:
Deal routing:
Measurement plan:
```

---

### Phase 9 — Technical SEO / CMS Requirements

Return:

```text
TECHNICAL REQUIREMENTS
CMS content types:
Fields:
URL rules:
Schema rules:
Canonical rules:
Index/noindex rules:
Sitemap rules:
Redirect rules:
Performance rules:
Accessibility rules:
Image rules:
QA checklist:
```

---

### Phase 10 — Production Roadmap

Return:

```text
CONTENT PRODUCTION ROADMAP
Priority:
Page type:
URL:
Brief status:
Owner:
Dependencies:
Expected impact:
Risk level:
Due date/trigger:
```

---

### Phase 11 — QA / Retry / Escalate

Run the 100-point QA rubric.

If the output scores below pass standard, feed back exact failures and retry up to two times.

Escalate if:

- Required source data is missing.
- Legal/claims risk remains.
- Strategy tradeoff is unresolved.
- Technical implementation is ambiguous.
- Deletion/redirect recommendation could harm traffic/revenue.
- Human approval is required.

---

### Phase 12 — Final Handoff

Return:

```text
FINAL SITE BUILD HANDOFF
Status:
QA score:
Recommendation:
Artifacts produced:
Key decisions:
Evidence reviewed:
Risks resolved:
Open risks:
Human approvals needed:
Implementation sequence:
Owners:
Next actions:
Skill/constraint updates:
```

---

## 14. 100-Point QA Rubric

| Category | Points |
|---|---:|
| Goal fit and scope control | 6 |
| Current Simply Rest site understanding | 8 |
| Internal source/context review | 6 |
| Competitive architecture insight without copying | 8 |
| Brand/positioning clarity | 7 |
| Information architecture and sitemap quality | 10 |
| SEO/topic universe strength | 9 |
| AEO/entity/extractability strength | 7 |
| Product evidence and review methodology | 10 |
| Page template completeness | 9 |
| CRO/affiliate/deal-routing quality | 6 |
| Technical SEO/CMS readiness | 6 |
| Claims/legal/sleep-health safety | 5 |
| Analytics and refresh operations | 2 |
| Final handoff quality | 1 |
| **Total** | **100** |

### Pass standard

```text
92–100 = Ready for human approval
85–91 = Revise and retry
Below 85 = Rebuild plan or escalate
Any auto-fail = Not ready
```

---

## 15. Universal Auto-Fail Conditions

The output automatically fails if it:

- Produces a shallow outline instead of a complete site-build package.
- Ignores the current Simply Rest site.
- Ignores internal project/source history when available.
- Copies competitor text, rankings, scores, images, or proprietary structures.
- Invents testing observations, product scores, claims, prices, specs, or approvals.
- Makes unsupported health, warranty, certification, price, deal, or comparative claims.
- Fails to preserve or resolve existing high-value pages.
- Recommends deleting/redirecting pages without traffic, search, link, revenue, replacement, and strategic review.
- Lacks a sitemap.
- Lacks page-type templates.
- Lacks a product/evidence database.
- Lacks review methodology.
- Lacks internal-linking plan.
- Lacks technical SEO/CMS requirements.
- Lacks claims/legal/sleep-health safety review.
- Leaves deal pages without refresh and verification rules.
- Leaves Mattress Reviews or another major hub empty without a fix plan.
- Fails to define human approval gates.
- Publishes, edits, sends, approves, or modifies anything without explicit approval.

---

## 16. Self-Improving Skill and Constraint Layer

After every run, update memory.

### STATE.md

```text
Run date:
Task:
Sources checked:
Artifacts produced:
QA score:
Failures:
Retries:
Open risks:
Human decisions needed:
Next action:
```

### CONSTRAINTS.md

Add permanent rules from verifier feedback.

Examples:

```text
- Do not claim firsthand testing unless internal testing evidence exists.
- Do not publish current-year deal pages without current deal verification.
- Do not recommend page deletion without performance/search/link/revenue/replacement review.
- Do not let major hubs exist as empty archive/search pages.
- Every Simply Rest commercial page must include who should buy, who should avoid, tradeoffs, evidence, and product-routing logic.
- Every health-sensitive page must use cautious informational framing and include medical disclaimer guidance.
```

### SKILLS.md

Save reusable workflows, such as:

- Simply Rest best mattress category page build.
- Simply Rest product review page build.
- Simply Rest deal page refresh.
- Simply Rest sleep-health safety review.
- Simply Rest site audit keep/delete loop.
- Simply Rest IA/sitemap rebuild.

---

## 17. Background-Agent Promotion Rules

Do not promote a loop to background automation until it has:

- Run successfully at least 3 times.
- Passed QA at least 2 times without major human edits.
- Clear trigger.
- Clear source scope.
- Clear output.
- Clear human approval gate.
- Clear cost cap.
- Clear failure/escalation path.
- State log.
- Owner.

Background candidates:

- Weekly deal page verification.
- Monthly outdated content detection.
- Quarterly page refresh prioritization.
- Weekly competitor architecture change monitor.
- Weekly broken/empty hub detection.
- Monthly GSC opportunity sweep.
- Monthly affiliate conversion anomaly review.

---

## 18. Final Operating Rule

For Simply Rest, the goal is not to build more pages.

The goal is to build a site system where every page has:

- A clear user job.
- A clear search intent.
- A clear recommendation logic.
- A clear evidence basis.
- Clear tradeoffs.
- Clear affiliate/shopping routing when relevant.
- Clear safety/disclosure controls.
- Clear internal links.
- Clear technical implementation rules.
- Clear refresh triggers.

Final principle:

> Build Simply Rest as a trusted sleep-product and sleep-health decision engine, not a generic affiliate blog.
