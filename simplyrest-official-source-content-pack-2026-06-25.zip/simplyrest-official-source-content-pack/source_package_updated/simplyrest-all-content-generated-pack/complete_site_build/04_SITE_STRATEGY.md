# Site Strategy

Position Simply Rest as the practical, evidence-led shopper guide for sleep products.

It should win by:

- explaining who each product is for and not for
- showing tradeoffs
- routing shoppers to reviews, comparisons, and deals
- building current-year answer blocks for AI extraction
- keeping medical/testing/certification claims conservative until proof exists

Primary moat:

Cleaner governance than MattressNut-style sites plus a stronger owned product/review/comparison system.
