# Launch Runbook

1. Complete URL decision matrix.
2. Publish foundation pages.
3. Publish llms.txt.
4. Publish reviews hub and product reviews.
5. Publish first comparison batch.
6. Publish/refresh best-of pages.
7. Validate schema.
8. Confirm sitemap inclusion.
9. Run technical re-QA commands.
10. Fill implementer return packet.
11. Joel reviews and approves publish/indexation.
