# Simply Rest Strategic Goal and Publish Gates

Date: 2026-06-22

## Strategic Goal

Turn `SimplyRest.com` into a MattressNut-style authority site, but with tighter proof discipline: crawlable pages, answer-first buying guides, comparison/review coverage, schema and LLM support, and conservative claims that avoid fake testing, weak medical language, or unverified product facts.

## Clean Explanation

Simply Rest is being rebuilt as an evidence-led sleep shopping resource. This package is a WordPress implementation kit with foundation pages, buying guides, product reviews, comparison pages, schema drafts, trackers, QA gates, and an `llms.txt` plan.

It is **not** meant to be blindly published. Each page still needs final URL decisions, current product fact checks, reviewer approval where relevant, schema validation, sitemap inclusion, and a MattressNut comparator pass before going live.

The strategic goal is for Simply Rest to own **evidence-forward buying guides for real sleeper problems**: practical recommendations, clear tradeoffs, who each mattress is and is not for, and AI-readable structure, while preserving existing URL equity wherever possible instead of creating duplicate 2026 URLs unnecessarily.

## Default Publish Posture

1. **Refresh before creating.** If an existing Simply Rest URL matches the same intent and has any traffic, links, ranking history, or internal links, update that URL instead of launching a duplicate current-year URL.
2. **Schema is a draft scaffold.** JSON-LD files must be validated and scrubbed of draft language before being added to WordPress.
3. **`llms.txt` is a final-step artifact.** Do not upload the package `llms.txt` until final canonical URLs are chosen and included in the sitemap.
4. **Reviewer attribution is gated.** Do not publish reviewer names, reviewer boxes, `reviewedBy`, or medical-adjacent authority language unless approval is documented.
5. **No fake testing.** Do not claim hands-on testing, lab testing, pressure mapping, thermal imaging, motion-transfer testing, or durability testing unless there is a product-specific record.
6. **No medical overreach.** Pain pages may discuss comfort, support, pressure relief, and alignment fit. They must not claim treatment, cure, prevention, diagnosis, or guaranteed relief.
7. **Product facts must be current.** Price, trial, warranty, firmness, materials, availability, fire-barrier/fiberglass status, certifications, and deal claims must be checked against current product sources before publication.

## Go / No-Go Gate

A page can go live only when all seven checks are marked complete:

- Final URL/canonical decision made.
- Product facts verified and source links recorded.
- Draft labels and verification language removed from visible copy.
- Claims cleared against methodology, disclosure, and health-safety rules.
- Schema validates and matches visible content.
- Page appears in the sitemap and the final `llms.txt` plan.
- MattressNut comparator row completed.
