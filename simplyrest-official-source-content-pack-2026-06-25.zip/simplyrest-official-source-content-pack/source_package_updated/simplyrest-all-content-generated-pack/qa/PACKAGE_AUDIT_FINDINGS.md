# Simply Rest Package Audit Findings

Date: 2026-06-22
Package audited: `simplyrest-mattressnut-build-2026-06-18.zip`

## TL;DR

The package is directionally strong as a **WordPress implementation kit**. It should not be treated as publish-ready copy. The highest-priority controls are URL preservation, draft-language cleanup, schema text cleanup, product fact verification, and MattressNut comparator completion.

## Inventory Checked

| Area | Count / finding |
|---|---:|
| Total files | 233 |
| Markdown files | 172 |
| JSON files | 47 |
| CSV trackers/maps | 12 |
| JSON parse failures | 0 |
| Package markdown files needing cleanup or expansion | 46 |
| JSON files with draft/pending/approval text | 38 |

## What Passed

- The package has full coverage across foundation pages, best-of pages, reviews, comparisons, site-level files, QA gates, evidence registers, and trackers.
- All JSON files parsed successfully in the automated check.
- No `TODO`, `TBD`, or `PLACEHOLDER` tokens were found in the Markdown files.
- The existing handoff already states that WordPress facts, prices, product claims, reviewer approval, and schema validity must be checked before publish.

## Blocking Issues Before Publish

### 1. URL decisions are unresolved

The package currently proposes multiple `*-2026` URLs, but spot checks found existing live Simply Rest URLs for overlapping intents. Default action should be to refresh existing URLs unless traffic/backlink/ranking data proves a new URL is better.

See: `qa/url_equity_external_spotcheck.csv`.

### 2. Draft language is intentionally present in source copy

The article files contain bracket section labels, verification rows, and phrases like `before publish`. This is acceptable for implementation scaffolding, but it is not acceptable on live pages.

See: `qa/content_cleanup_queue.csv`.

### 3. JSON-LD includes draft/pending language in multiple schema files

The JSON files parse correctly, but several contain text such as `draft`, `pending`, or `approval`. This should not be exposed to crawlers. Before schema is pasted into WordPress, these strings must be removed or rewritten to match final visible page copy.

See: `qa/schema_publish_safety_queue.csv`.

### 4. Most article bodies are not publish-length articles yet

The best-of pages are structured briefs, not complete article bodies. Reviews and comparison pages are especially thin and need expansion before they can compete with MattressNut-style pages.

### 5. `llms.txt` is provisional

`package/site/llms.txt` points to package canonical URLs before final URL decisions. It should be treated as a plan, not uploaded as-is.

### 6. Reviewer attribution is not approval

Reviewer names appear in front matter and trackers. That is not enough to publish reviewer boxes, medical-adjacent authority language, or `reviewedBy` schema.

## Recommended Build Order From Here

1. Resolve URL decisions and update canonical URLs across Markdown, JSON-LD, trackers, sitemap, and `llms.txt`.
2. Publish or refresh foundation pages: methodology, editorial policy, disclosure, expert reviewers.
3. Fill the product evidence register for every mattress used in a table or winner box.
4. Expand one pilot page end-to-end, preferably a page with an existing URL and high commercial value.
5. Validate schema and sitemap inclusion for the pilot before scaling.
6. Run the MattressNut comparator pass page by page.
7. Publish in batches, not all at once.

## Files Added By This Audit Layer

- `00_STRATEGIC_GOAL_AND_PUBLISH_GATES.md`
- `implementation/09_LAUNCH_CONTROL_PLAYBOOK.md`
- `implementation/10_URL_REFRESH_DECISION_NOTES.md`
- `qa/PACKAGE_AUDIT_FINDINGS.md`
- `qa/content_cleanup_queue.csv`
- `qa/schema_publish_safety_queue.csv`
- `qa/url_equity_external_spotcheck.csv`
- `trackers/simplyrest_go_live_gate_tracker.csv`
