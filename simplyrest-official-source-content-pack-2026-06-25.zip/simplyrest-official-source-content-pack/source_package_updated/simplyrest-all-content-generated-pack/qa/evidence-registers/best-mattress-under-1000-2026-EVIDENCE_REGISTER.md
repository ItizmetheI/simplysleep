# Evidence Register - Best Mattress Under $1000 in 2026: Value Picks That Still Feel Supportive

## Current Evidence Sources To Attach

- Current Simply Rest page, if it exists.
- Current product pages for every recommended mattress.
- Reviewer approval note.
- MattressNut comparator URL.
- Any certification IDs or public verification pages used.
- WordPress permalink and schema validation result.

## Claims Allowed In Draft

- shopper fit
- support/alignment potential
- pressure relief potential
- cooling/breathability design language
- value and product-feature comparisons after fact check

## Claims Blocked Unless Proven

- hands-on tested by Simply Rest
- clinically proven pain relief
- cures, treats, prevents, or diagnoses
- whole-product organic/non-toxic/certified claims without exact proof
