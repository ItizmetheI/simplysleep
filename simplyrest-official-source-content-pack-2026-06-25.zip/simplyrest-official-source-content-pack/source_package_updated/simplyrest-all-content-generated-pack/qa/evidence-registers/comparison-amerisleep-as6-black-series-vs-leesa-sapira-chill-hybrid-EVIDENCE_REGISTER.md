# Evidence Register - AS6 Black Series vs Leesa Sapira Chill Hybrid

## Evidence To Attach

- Current product page facts.
- Final WordPress URL.
- Schema validation result.
- MattressNut or competitor comparator if relevant.
- CTA/link approval.

## Blocked Unless Proven

- hands-on tested by Simply Rest
- lab testing or scoring
- medical treatment language
- whole-product certification claims
- reviewer approval/schema
