# QA Gate - Amerisleep AS6 Black Series Mattress Review

Canonical: https://simplyrest.com/reviews/amerisleep-as6/
Type: review

## Required Before Publish

- [ ] WordPress URL confirmed.
- [ ] Current product facts checked.
- [ ] JSON-LD validates.
- [ ] Page added to sitemap.
- [ ] Page added to `/llms.txt`.
- [ ] No unsupported testing claims.
- [ ] No unsupported medical claims.
- [ ] No unsupported certification claims.
- [ ] No unsupported reviewer/person schema.
