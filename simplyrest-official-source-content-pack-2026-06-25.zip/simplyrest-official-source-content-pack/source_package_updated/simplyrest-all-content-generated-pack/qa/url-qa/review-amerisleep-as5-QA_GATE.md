# QA Gate - Amerisleep AS5 Mattress Review

Canonical: https://simplyrest.com/reviews/amerisleep-as5/
Type: review

## Required Before Publish

- [ ] WordPress URL confirmed.
- [ ] Current product facts checked.
- [ ] JSON-LD validates.
- [ ] Page added to sitemap.
- [ ] Page added to `/llms.txt`.
- [ ] No unsupported testing claims.
- [ ] No unsupported medical claims.
- [ ] No unsupported certification claims.
- [ ] No unsupported reviewer/person schema.
