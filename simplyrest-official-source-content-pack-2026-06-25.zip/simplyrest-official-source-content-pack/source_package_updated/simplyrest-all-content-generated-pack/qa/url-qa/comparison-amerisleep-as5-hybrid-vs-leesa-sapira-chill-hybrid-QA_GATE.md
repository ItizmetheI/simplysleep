# QA Gate - AS5 Hybrid vs Leesa Sapira Chill Hybrid

Canonical: https://simplyrest.com/comparison/amerisleep-as5-hybrid-vs-leesa-sapira-chill-hybrid/
Type: comparison

## Required Before Publish

- [ ] WordPress URL confirmed.
- [ ] Current product facts checked.
- [ ] JSON-LD validates.
- [ ] Page added to sitemap.
- [ ] Page added to `/llms.txt`.
- [ ] No unsupported testing claims.
- [ ] No unsupported medical claims.
- [ ] No unsupported certification claims.
- [ ] No unsupported reviewer/person schema.
