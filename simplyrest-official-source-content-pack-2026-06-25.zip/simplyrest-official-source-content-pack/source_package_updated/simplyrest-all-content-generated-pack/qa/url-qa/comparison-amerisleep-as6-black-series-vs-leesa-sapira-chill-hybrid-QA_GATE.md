# QA Gate - AS6 Black Series vs Leesa Sapira Chill Hybrid

Canonical: https://simplyrest.com/comparison/amerisleep-as6-black-series-vs-leesa-sapira-chill-hybrid/
Type: comparison

## Required Before Publish

- [ ] WordPress URL confirmed.
- [ ] Current product facts checked.
- [ ] JSON-LD validates.
- [ ] Page added to sitemap.
- [ ] Page added to `/llms.txt`.
- [ ] No unsupported testing claims.
- [ ] No unsupported medical claims.
- [ ] No unsupported certification claims.
- [ ] No unsupported reviewer/person schema.
