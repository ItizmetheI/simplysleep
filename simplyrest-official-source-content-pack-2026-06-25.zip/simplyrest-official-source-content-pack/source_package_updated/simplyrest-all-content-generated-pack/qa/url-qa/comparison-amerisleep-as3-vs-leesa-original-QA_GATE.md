# QA Gate - AS3 vs Leesa Original

Canonical: https://simplyrest.com/comparison/amerisleep-as3-vs-leesa-original/
Type: comparison

## Required Before Publish

- [ ] WordPress URL confirmed.
- [ ] Current product facts checked.
- [ ] JSON-LD validates.
- [ ] Page added to sitemap.
- [ ] Page added to `/llms.txt`.
- [ ] No unsupported testing claims.
- [ ] No unsupported medical claims.
- [ ] No unsupported certification claims.
- [ ] No unsupported reviewer/person schema.
