# QA Gate - Simply Rest Mattress Reviews

Canonical: https://simplyrest.com/reviews/
Type: review

## Required Before Publish

- [ ] WordPress URL confirmed.
- [ ] Current product facts checked.
- [ ] JSON-LD validates.
- [ ] Page added to sitemap.
- [ ] Page added to `/llms.txt`.
- [ ] No unsupported testing claims.
- [ ] No unsupported medical claims.
- [ ] No unsupported certification claims.
- [ ] No unsupported reviewer/person schema.
