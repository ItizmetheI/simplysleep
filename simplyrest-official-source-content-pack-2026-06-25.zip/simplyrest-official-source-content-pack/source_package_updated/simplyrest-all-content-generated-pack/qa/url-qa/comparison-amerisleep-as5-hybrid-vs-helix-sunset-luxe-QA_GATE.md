# QA Gate - AS5 Hybrid vs Helix Sunset Luxe

Canonical: https://simplyrest.com/comparison/amerisleep-as5-hybrid-vs-helix-sunset-luxe/
Type: comparison

## Required Before Publish

- [ ] WordPress URL confirmed.
- [ ] Current product facts checked.
- [ ] JSON-LD validates.
- [ ] Page added to sitemap.
- [ ] Page added to `/llms.txt`.
- [ ] No unsupported testing claims.
- [ ] No unsupported medical claims.
- [ ] No unsupported certification claims.
- [ ] No unsupported reviewer/person schema.
