# Issues And Fixes - Best Mattress for Heavy People 2026: Supportive Beds That Feel Stable

## Open Issues

- Verify whether an existing Simply Rest URL should be refreshed instead of creating `https://simplyrest.com/whats-the-best-mattress-for-plus-size-people/`.
- Confirm final product order and commercial routing.
- Confirm reviewer assignment and whether `reviewedBy` schema may deploy.
- Add exact MattressNut comparator URL.

## Default Fixes

- Use shopper-fit language.
- Keep claims current-year but not overconfident.
- Use component-specific certification language.
- Remove any claim that cannot be traced to product canon, reviewer approval, or visible source.
