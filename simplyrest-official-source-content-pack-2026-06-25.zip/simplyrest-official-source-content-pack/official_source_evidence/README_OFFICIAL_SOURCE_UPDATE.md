# Simply Rest Official-Source Content Update

Generated: 2026-06-25

## What changed

All guide, review, comparison, merge-source, and foundation Markdown files were regenerated to use product facts gathered from official brand/product/support/policy pages instead of generic placeholders.

## What this does not do

This package still does not hard-code live prices, promotions, inventory, or affiliate URLs. Those are volatile commercial values and should be refreshed in WordPress or the affiliate/deal module immediately before publication.

## Files in this folder

- `OFFICIAL_PRODUCT_FACT_DATABASE.csv` — normalized product facts used across the content.
- `OFFICIAL_SOURCE_REGISTER.csv` — official URLs consulted and what each source supports.
- `FINAL_CMS_QA_REMAINING_ITEMS.csv` — model-name, fire-barrier, price, schema, and live-CMS checks that remain before publish.

## Stella instructions

1. Open the page being built in `wordpress_public_body_copy/`.
2. Use the matching source-backed QA draft in `wordpress_content_ready_for_qa/` for front matter, schema file references, and source notes.
3. Refresh live price, promo, inventory, and affiliate URL on publish day.
4. Check any product with a row in `FINAL_CMS_QA_REMAINING_ITEMS.csv` before publishing a claim about exact height, fire-barrier/fiberglass, or current model name.
5. Validate schema after the visible page content is final.
