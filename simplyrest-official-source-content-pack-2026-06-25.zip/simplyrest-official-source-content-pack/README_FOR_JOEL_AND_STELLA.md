# Simply Rest Official-Source Content Pack

Generated: 2026-06-25

## TL;DR

This package continues the Simply Rest / MattressNut-style rebuild, but the content has now been regenerated using official brand/product/support pages for product facts. It is no longer a placeholder-only content draft.

## Start here

- Public WordPress body copy: `wordpress_public_body_copy/`
- Full QA Markdown with front matter and source notes: `wordpress_content_ready_for_qa/`
- Official product fact database: `official_source_evidence/OFFICIAL_PRODUCT_FACT_DATABASE.csv`
- Source register: `official_source_evidence/OFFICIAL_SOURCE_REGISTER.csv`
- Remaining publish checks: `official_source_evidence/FINAL_CMS_QA_REMAINING_ITEMS.csv`

## Controlling URL rule

If a topic overlaps an existing SimplyRest.com URL, refresh the current URL. Do not create a duplicate `*-2026` URL.

## Still required before live publication

1. Replace affiliate-link placeholders with live affiliate/deal URLs.
2. Refresh live price, sale, bundle, inventory, shipping timing, and return terms on publish day.
3. Confirm exact product naming where the source evidence indicates a route may have changed, especially Bear Star Hybrid, GhostBed Flex, and Dreamfoam Essential/CopperFlex Essential.
4. Validate page schema after visible copy is final.
5. Run final legal/editorial review for pain, medical, certification, and fiberglass/fire-barrier claims.
