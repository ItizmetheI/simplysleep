# Expert Reviewers

Reviewer names should be used only when the reviewer has actually approved the page or claim. A name in a draft is not approval evidence.

## Reviewer approval standard

A page can say it was reviewed only after Simply Rest has a dated approval record showing who reviewed it, what they reviewed, and whether any claims were changed. Medical, pain, spinal-alignment, or health-adjacent pages require extra caution and should not present mattress shopping advice as medical treatment.

## Safe reviewer language

Use precise language such as “Reviewed for editorial accuracy” or “Reviewed for claim safety” only when that is true. Avoid implying clinical endorsement of a mattress unless a qualified reviewer specifically approved that wording.
