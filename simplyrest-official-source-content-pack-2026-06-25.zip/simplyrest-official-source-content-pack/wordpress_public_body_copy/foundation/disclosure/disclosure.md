# Affiliate Disclosure

Simply Rest may earn a commission when readers buy through links on the site. That commercial relationship should not change the editorial standard: recommendations should explain who a mattress is for, who should skip it, what tradeoffs matter, and which facts came from official brand/product/support pages.

## What this means for readers

- Buying through a Simply Rest link may generate revenue for the site.
- Rankings should still be based on shopper fit, source-backed product facts, tradeoffs, and current terms.
- Prices, coupons, bundles, shipping, returns, warranties, and availability can change, so readers should confirm the current offer before buying.

## Claims standard

Simply Rest should not publish unsupported testing claims, unsupported medical language, broad certification claims, or product facts that were not checked against a current source.
