# Editorial Policy

Simply Rest is being rebuilt as an evidence-led sleep shopping resource. Every buying guide, review, and comparison should help readers make a practical purchase decision without pretending the site performed testing it did not perform.

## Editorial rules

1. Preserve existing URL equity when an existing SimplyRest.com URL already matches the search intent.
2. Use official product, brand, support, policy, and certification sources for product facts.
3. Distinguish stable facts from volatile facts. Construction, trial, and warranty can be summarized when sourced; price, coupon, inventory, and shipping timing must be refreshed near publication.
4. Avoid medical promises. Use “support,” “comfort,” “pressure relief,” and “fit” language rather than treatment claims.
5. Keep certification scope exact. Do not turn a component certification into a finished-product certification.
6. Update schema only after the visible page content is final.
