# Stella: Remaining Fact Checks After Official-Source Content Update

Generated: 2026-06-25

The content has been updated from official brand/product/support pages. Your remaining work is not to rewrite generic placeholders; it is to confirm volatile or configuration-specific items before WordPress publication.

## Required per page

1. Open the official source URLs listed in `official_source_evidence/OFFICIAL_PRODUCT_FACT_DATABASE.csv` for every product on the page.
2. Confirm live product name, active model, selected configuration, height, firmness, current price, coupon, inventory, shipping timing, trial, return fee/minimum, warranty, and affiliate URL.
3. Replace `{AFFILIATE_LINK:...}` placeholders in WordPress with the approved affiliate/deal URL.
4. Do not hard-code prices unless you also add a “last checked” date and owner.
5. Validate JSON-LD only after final visible copy is entered.

## Higher-risk checks

- **Bear Star Hybrid** — confirm whether it remains an active product page or should map to Bear Pro Hybrid / Bear Elite Hybrid.
- **GhostBed Flex** — confirm current model name/URL; current source route may be GhostBed Signature Hybrid.
- **Dreamfoam Essential** — current public route appears to be CopperFlex Essential; decide whether public page should use the current product name.
- **Any fiberglass-free claim** — must match exact model-source or law-tag language.
- **Any medical/pain page** — must avoid treatment/cure/prevention promises.
